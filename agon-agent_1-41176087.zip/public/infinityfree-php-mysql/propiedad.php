<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$pdo = eyn_db();
$settings = eyn_load_settings($pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare('SELECT * FROM eyn_properties WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$prop = $stmt->fetch();

if (!$prop) {
    header('Location: index.php');
    exit;
}

$highlights = json_decode((string)($prop['highlights'] ?? '[]'), true) ?: [];
$sentOk = false;
$errMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errMsg = 'Token de seguridad inválido.';
    } else {
        $name = trim(strip_tags((string)($_POST['full_name'] ?? '')));
        $phone = trim(strip_tags((string)($_POST['phone'] ?? '')));
        $email = trim((string)($_POST['email'] ?? ''));
        $msg = trim(strip_tags((string)($_POST['message'] ?? '')));
        if ($name && $phone && filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($_POST['gdpr'])) {
            $ins = $pdo->prepare(
                'INSERT INTO eyn_inquiries (full_name, phone, email, service_type, property_id, property_ref, message, gdpr_accepted, status)
                 VALUES (:n, :p, :e, :s, :pid, :pref, :m, 1, "Nueva")'
            );
            $ins->execute([
                ':n' => mb_substr($name, 0, 120),
                ':p' => mb_substr($phone, 0, 40),
                ':e' => mb_substr($email, 0, 150),
                ':s' => 'Visita / Dossier (' . $prop['operation'] . ')',
                ':pid' => (int)$prop['id'],
                ':pref' => $prop['reference'],
                ':m' => $msg ?: 'Solicito información sobre ' . $prop['reference'],
            ]);
            $sentOk = true;
        } else {
            $errMsg = 'Por favor, complete todos los campos obligatorios y acepte la privacidad.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($prop['title']) ?> | EYN LUXE Valencia</title>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { margin:0; background:#0A0A0C; color:#F5F1E8; font-family:'Plus Jakarta Sans',sans-serif; }
    .serif { font-family:'Cormorant Garamond',serif; }
    .wrap { max-width:1160px; margin:0 auto; padding:36px 24px 80px; }
    a { color:#DFC286; text-decoration:none; }
    .grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:36px; margin-top:28px; }
    .box { background:#131318; border:1px solid rgba(197,160,89,.28); border-radius:24px; padding:28px; }
    input,textarea { width:100%; box-sizing:border-box; padding:12px 14px; border-radius:12px; background:#0A0A0C; border:1px solid rgba(255,255,255,.15); color:#fff; margin-bottom:12px; font-family:inherit; }
    .btn { width:100%; padding:14px; border-radius:999px; border:none; background:linear-gradient(90deg,#C5A059,#DFC286); color:#0A0A0C; font-weight:700; text-transform:uppercase; letter-spacing:.14em; cursor:pointer; }
  </style>
</head>
<body>
<div class="wrap">
  <a href="index.php#catalogo">← Volver al catálogo de EYN LUXE</a>

  <div class="grid">
    <div>
      <img src="<?= e($prop['main_image']) ?>" alt="<?= e($prop['title']) ?>" style="width:100%;height:420px;object-fit:cover;border-radius:24px;border:1px solid rgba(197,160,89,.3);">
      <h1 class="serif" style="font-size:42px;color:#fff;font-weight:400;margin:22px 0 8px;"><?= e($prop['title']) ?></h1>
      <p style="color:#C5A059;font-size:14px;"><?= e($prop['zone']) ?> · Ref. <?= e($prop['reference']) ?></p>
      <p style="line-height:1.75;color:rgba(245,241,232,.84);margin-top:18px;"><?= nl2br(e($prop['description'])) ?></p>

      <?php if ($highlights): ?>
        <h3 class="serif" style="font-size:26px;color:#fff;margin-top:26px;">Características Destacadas</h3>
        <ul style="line-height:1.9;color:rgba(245,241,232,.8);">
          <?php foreach ($highlights as $h): ?>
            <li><?= e((string)$h) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <div class="box">
      <p style="font-size:12px;text-transform:uppercase;letter-spacing:.18em;color:#C5A059;"><?= e($prop['operation']) ?></p>
      <p class="serif" style="font-size:36px;color:#DFC286;margin:8px 0 18px;">
        <?= e($prop['price_label'] ?: number_format((float)$prop['price'], 0, ',', '.') . ' €') ?>
      </p>
      <p style="font-size:14px;color:rgba(245,241,232,.8);margin-bottom:22px;">
        Superficie: <strong><?= (int)$prop['area_m2'] ?> m²</strong> · Dormitorios: <strong><?= (int)$prop['bedrooms'] ?></strong> · Baños: <strong><?= (int)$prop['bathrooms'] ?></strong> · Energía: <strong><?= e($prop['energy_rating']) ?></strong>
      </p>

      <h3 class="serif" style="font-size:26px;color:#fff;margin-bottom:14px;">Solicitar Visita o Dossier</h3>
      <?php if ($sentOk): ?>
        <p style="padding:16px;background:rgba(197,160,89,.18);border-radius:14px;">Solicitud recibida. <?= e($settings['director_name']) ?> contactará con usted personalmente.</p>
      <?php else: ?>
        <?php if ($errMsg): ?><p style="color:#ef9a9a;font-size:13px;"><?= e($errMsg) ?></p><?php endif; ?>
        <form method="post">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="text" name="full_name" required placeholder="Nombre completo *">
          <input type="tel" name="phone" required placeholder="Teléfono *">
          <input type="email" name="email" required placeholder="Correo electrónico *">
          <textarea name="message" rows="3" placeholder="Disponibilidad o consulta..."></textarea>
          <label style="font-size:12px;display:block;margin-bottom:14px;">
            <input type="checkbox" name="gdpr" value="1" required style="width:auto;"> Acepto la Política de Privacidad de EYN LUXE.
          </label>
          <button type="submit" class="btn">Solicitar Atención Directa</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
