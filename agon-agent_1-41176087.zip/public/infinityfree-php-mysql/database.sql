-- ============================================================================
-- EYN LUXE – Exclusive Real Estate (Valencia, España)
-- Responsable: Estefanía Yáñez | Contacto: +34 658 659 387
-- Base de datos MySQL compatible con InfinityFree (MySQL 5.7 / 8.0 / MariaDB)
-- Importar directamente desde phpMyAdmin en el panel de InfinityFree
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `eyn_admins` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(160) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(120) NOT NULL DEFAULT 'Estefanía Yáñez',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Usuario inicial: admin@eynluxe.es | Contraseña inicial (cambiar tras primer acceso): EynLuxe2026!
INSERT IGNORE INTO `eyn_admins` (`id`, `email`, `password_hash`, `full_name`) VALUES
(1, 'admin@eynluxe.es', '$2y$10$wS6x0lZ3yQ8n6k2wR5jM2eN1rT9pL4vC8xH7bF0gD3sA5kM8qW1zO', 'Estefanía Yáñez');

CREATE TABLE IF NOT EXISTS `eyn_properties` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference` VARCHAR(50) NOT NULL,
  `slug` VARCHAR(180) NOT NULL,
  `title` VARCHAR(220) NOT NULL,
  `subtitle` VARCHAR(255) DEFAULT NULL,
  `operation` VARCHAR(60) NOT NULL DEFAULT 'Venta',
  `property_type` VARCHAR(80) NOT NULL DEFAULT 'Vivienda Exclusiva',
  `zone` VARCHAR(140) NOT NULL,
  `city` VARCHAR(80) NOT NULL DEFAULT 'Valencia',
  `price` DECIMAL(14,2) NOT NULL DEFAULT 0,
  `price_label` VARCHAR(80) DEFAULT NULL,
  `area_m2` INT NOT NULL DEFAULT 0,
  `plot_m2` INT NOT NULL DEFAULT 0,
  `bedrooms` INT NOT NULL DEFAULT 0,
  `bathrooms` INT NOT NULL DEFAULT 0,
  `energy_rating` VARCHAR(20) DEFAULT 'A',
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `exclusive_badge` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(30) NOT NULL DEFAULT 'Disponible',
  `description` TEXT NOT NULL,
  `highlights` TEXT DEFAULT NULL,
  `main_image` VARCHAR(500) NOT NULL,
  `gallery` TEXT DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 10,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_operation` (`operation`),
  INDEX `idx_status` (`status`),
  INDEX `idx_featured` (`featured`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `eyn_properties` (`reference`, `slug`, `title`, `subtitle`, `operation`, `property_type`, `zone`, `city`, `price`, `price_label`, `area_m2`, `plot_m2`, `bedrooms`, `bathrooms`, `energy_rating`, `featured`, `exclusive_badge`, `status`, `description`, `highlights`, `main_image`, `gallery`, `sort_order`) VALUES
('EYN-VLC-001', 'atico-duplex-jardines-del-turia', 'Ático Dúplex sobre los Jardines del Turia', 'Terraza panorámica privada de 95 m² y reforma integral con materiales nobles.', 'Comercialización Exclusiva', 'Ático Dúplex', 'El Pla del Real · Valencia', 'Valencia', 1950000, '1.950.000 €', 285, 0, 4, 4, 'A', 1, 1, 'Disponible', 'Excepcional ático dúplex orientado al sur con vistas despejadas sobre el antiguo cauce del río Turia. Proyecto de interiorismo contemporáneo con pavimento de roble natural en espiga, piedra caliza apomazada, sistema de aerotermia oculta y domótica integral.', '["Terraza ajardinada de 95 m² con zona lounge exterior","2 plazas de garaje de acceso directo y trastero","Cocina de autor integrada con isla monolítica","Seguridad y conserjería en finca representativa"]', 'images/penthouse-turia.jpg', '["images/penthouse-turia.jpg","images/interior-salon.jpg","images/interior-cocina.jpg"]', 1),
('EYN-VLC-002', 'villa-arquitectonica-los-monasterios', 'Villa Contemporánea con Piscina Desbordante', 'Arquitectura mediterránea de líneas puras en urbanización privada con seguridad 24 h.', 'Venta', 'Villa Independiente', 'Los Monasterios · Puzol (Valencia)', 'Valencia', 2680000, '2.680.000 €', 490, 1280, 5, 6, 'A', 1, 1, 'Disponible', 'Residencia independiente concebida para fundir interior y paisaje mediterráneo mediante grandes paños acristalados de suelo a techo. Cuenta con salón a doble altura, suite principal con terraza privada al mar y Sierra Calderona, bodega climatizada y piscina infinity salina.', '["Parcela paisajística de 1.280 m² con máxima privacidad","Seguridad privada 24 horas y club social exclusivo","Eficiencia energética Clase A con placas fotovoltaicas","Piscina desbordante climatizada y porche de verano"]', 'images/villa-monasterios.jpg', '["images/villa-monasterios.jpg","images/hero-villa.jpg","images/interior-salon.jpg"]', 2),
('EYN-VLC-003', 'residencia-senorial-la-xerea', 'Residencia Señorial Rehabilitada en La Xerea', 'Techos de 3,8 metros, balcones históricos y elegancia contemporánea en Ciutat Vella.', 'Venta', 'Piso Representativo', 'Ciutat Vella · La Xerea, Valencia', 'Valencia', 1420000, '1.420.000 €', 240, 0, 3, 3, 'B', 1, 1, 'Disponible', 'Vivienda única en edificio clásico rehabilitado íntegramente junto a la calle de la Paz y los Jardines de la Glorieta. Conserva carpinterías nobles recuperadas combinadas con aislamiento acústico y térmico de última generación.', '["Tres suites completas con vestidor a medida","Balcones exteriores orientados a calle peatonal tranquila","Molduras artesanales y luz natural todo el día","Plaza de aparcamiento en la misma finca"]', 'images/palacete-xerea.jpg', '["images/palacete-xerea.jpg","images/interior-cocina.jpg","images/valencia-historic.jpg"]', 3),
('EYN-VLC-004', 'atico-frente-al-mar-patacona', 'Residencia Frente al Mar Mediterráneo', 'Primera línea frontal con terraza solárium y brisa marina durante todo el año.', 'Alquiler', 'Ático Frente al Mar', 'Playa de la Patacona · Valencia', 'Valencia', 4800, '4.800 € / mes', 195, 0, 3, 3, 'A', 1, 1, 'Disponible', 'Exclusiva vivienda en alquiler residencial de larga estancia situada en primera línea de playa, completamente amueblada con piezas de diseño contemporáneo y equipada para entrar a vivir con el máximo confort.', '["Vistas frontales ininterrumpidas al Mediterráneo","Totalmente equipada con mobiliario de alta gama","Complejo privado con piscina y conserjería","Dos plazas de garaje incluidas"]', 'images/atico-patacona.jpg', '["images/atico-patacona.jpg","images/valencia-coast.jpg"]', 4),
('EYN-VLC-005', 'proyecto-construccion-campolivar', 'Proyecto de Construcción Llave en Mano', 'Diseño arquitectónico personalizado sobre parcela exclusiva en Campolivar.', 'Construcción', 'Obra Nueva a Medida', 'Campolivar · Godella (Valencia)', 'Valencia', 1790000, '1.790.000 €', 380, 960, 4, 5, 'A', 0, 1, 'Disponible', 'Proyecto integral de arquitectura y construcción gestionado por EYN LUXE con personalización completa de distribución, acabados interiores, paisajismo y equipamiento tecnológico con plazos y presupuesto cerrados por contrato.', '["Arquitectura a medida adaptada a su estilo de vida","Dirección técnica, licencias y ejecución llave en mano","Certificación de máxima eficiencia energética A","Acabados en piedra natural, madera noble y acero negro"]', 'images/villa-campolivar.jpg', '["images/villa-campolivar.jpg","images/obra-nueva-cortes.jpg"]', 5);

CREATE TABLE IF NOT EXISTS `eyn_inquiries` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(40) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `service_type` VARCHAR(80) NOT NULL,
  `property_id` INT UNSIGNED DEFAULT NULL,
  `property_ref` VARCHAR(50) DEFAULT NULL,
  `preferred_contact` VARCHAR(50) DEFAULT 'Teléfono / WhatsApp',
  `budget_or_valuation` VARCHAR(120) DEFAULT NULL,
  `message` TEXT NOT NULL,
  `gdpr_accepted` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(30) NOT NULL DEFAULT 'Nueva',
  `admin_notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS `eyn_faqs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `question` VARCHAR(300) NOT NULL,
  `answer` TEXT NOT NULL,
  `category` VARCHAR(80) DEFAULT 'General',
  `sort_order` INT DEFAULT 10,
  `visible` TINYINT(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `eyn_faqs` (`question`, `answer`, `category`, `sort_order`, `visible`) VALUES
('¿Qué diferencia aporta la comercialización exclusiva con EYN LUXE?', 'Trabajamos con una cartera reducida para dedicar a cada propiedad una estrategia a medida: reportaje arquitectónico profesional, posicionamiento editorial, difusión selectiva entre compradores solventes y un único interlocutor directo con Estefanía Yáñez.', 'Venta', 1, 1),
('¿Cómo seleccionan a los compradores o arrendatarios antes de una visita?', 'Protegemos su tiempo y su privacidad verificando previamente el interés real, encaje de necesidades y solvencia financiera de cada candidato antes de coordinar cualquier visita presencial en Valencia.', 'Seguridad', 2, 1),
('¿Gestionan también proyectos de construcción y reforma integral?', 'Sí. Acompañamos tanto la compra de suelo o viviendas para rehabilitar como la ejecución integral de proyectos de construcción y reforma de alto nivel en Valencia y su área metropolitana, controlando calidades, licencias y plazos.', 'Construcción', 3, 1),
('¿Disponen de propiedades confidenciales (off-market) que no aparecen publicadas?', 'Efectivamente. Por expreso deseo de determinados propietarios, gestionamos activos singulares en régimen privado. Puede solicitar asesoramiento personalizado para acceder a oportunidades acordes a sus criterios.', 'Compra', 4, 1);

CREATE TABLE IF NOT EXISTS `eyn_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT IGNORE INTO `eyn_settings` (`setting_key`, `setting_value`) VALUES
('brand_name', 'EYN LUXE'),
('brand_subtitle', 'Exclusive Real Estate'),
('director_name', 'Estefanía Yáñez'),
('location', 'Valencia, España'),
('phone_display', '+34 658 659 387'),
('phone_clean', '34658659387'),
('corporate_email', ''),
('postal_address', 'Valencia, España (Atención personalizada con cita previa)'),
('hero_slogan', 'Propiedades exclusivas para personas excepcionales.'),
('key_message', 'Tu propiedad merece destacar, no solo anunciarse.');

SET FOREIGN_KEY_CHECKS = 1;
