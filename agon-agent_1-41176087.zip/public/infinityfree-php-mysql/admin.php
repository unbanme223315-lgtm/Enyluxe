<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$pdo = eyn_db();
$notice = '';
$error = '';

// Cerrar sesión
if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Autenticación segura con password_verify + creación automática de primer hash si la tabla estuviera vacía
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Token CSRF inválido.';
    } else {
        $email = trim((string)($_POST['email'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');

        $countAdmins = (int)$pdo->query('SELECT COUNT(*) FROM eyn_admins')->fetchColumn();
        if ($countAdmins === 0 && $email === 'admin@eynluxe.es') {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $pdo->prepare('INSERT INTO eyn_admins (email, password_hash) VALUES (?, ?)')->execute([$email, $hash]);
        }

        $stmt = $pdo->prepare('SELECT * FROM eyn_admins WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($pass, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['eyn_admin_id'] = (int)$admin['id'];
            $_SESSION['eyn_admin_email'] = $admin['email'];
            header('Location: admin.php');
            exit;
        } else {
            $error = 'Credenciales incorrectas.';
        }
    }
}

$isLogged = !empty($_SESSION['eyn_admin_id']);

// Operaciones protegidas CRUD
if ($isLogged && $_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf_token'] ?? '')) {
    $act = $_POST['action'] ?? '';

    if ($act === 'create_property') {
        $imgPath = trim((string)($_POST['main_image'] ?? 'images/hero-villa.jpg'));
        if (!empty($_FILES['photo']['tmp_name']) && is_uploaded_file($_FILES['photo']['tmp_name'])) {
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            $mime = mime_content_type($_FILES['photo']['tmp_name']) ?: '';
            if (isset($allowed[$mime])) {
                if (!is_dir(__DIR__ . '/uploads')) {
                    mkdir(__DIR__ . '/uploads', 0755, true);
                }
                $dest = 'uploads/prop_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
                if (move_uploaded_file($_FILES['photo']['tmp_name'], __DIR__ . '/' . $dest)) {
                    $imgPath = $dest;
                }
            }
        }

        $title = trim((string)($_POST['title'] ?? ''));
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $title)) . '-' . rand(100, 999);
        $ins = $pdo->prepare(
            'INSERT INTO eyn_properties (reference, slug, title, operation, property_type, zone, price, price_label, area_m2, bedrooms, bathrooms, featured, status, description, main_image)
             VALUES (:ref, :slug, :title, :op, :ptype, :zone, :price, :plabel, :area, :beds, :baths, :feat, :status, :descr, :img)'
        );
        $ins->execute([
            ':ref' => trim((string)$_POST['reference']),
            ':slug' => $slug,
            ':title' => $title,
            ':op' => $_POST['operation'] ?? 'Venta',
            ':ptype' => trim((string)($_POST['property_type'] ?? 'Vivienda Exclusiva')),
            ':zone' => trim((string)$_POST['zone']),
            ':price' => (float)($_POST['price'] ?? 0),
            ':plabel' => trim((string)($_POST['price_label'] ?? '')),
            ':area' => (int)($_POST['area_m2'] ?? 0),
            ':beds' => (int)($_POST['bedrooms'] ?? 0),
            ':baths' => (int)($_POST['bathrooms'] ?? 0),
            ':feat' => !empty($_POST['featured']) ? 1 : 0,
            ':status' => $_POST['status'] ?? 'Disponible',
            ':descr' => trim((string)$_POST['description']),
            ':img' => $imgPath,
        ]);
        $notice = 'Propiedad publicada correctamente.';
    }

    if ($act === 'delete_property') {
        $pdo->prepare('DELETE FROM eyn_properties WHERE id = :id')->execute([':id' => (int)$_POST['id']]);
        $notice = 'Propiedad eliminada.';
    }

    if ($act === 'update_password') {
        $newPass = (string)($_POST['new_password'] ?? '');
        if (strlen($newPass) >= 8) {
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            $pdo->prepare('UPDATE eyn_admins SET password_hash = :h WHERE id = :id')
                ->execute([':h' => $hash, ':id' => (int)$_SESSION['eyn_admin_id']]);
            $notice = 'Contraseña actualizada de forma segura.';
        } else {
            $error = 'La nueva contraseña debe tener al menos 8 caracteres.';
        }
    }
}

$props = $isLogged ? $pdo->query('SELECT * FROM eyn_properties ORDER BY id DESC')->fetchAll() : [];
$inquiries = $isLogged ? $pdo->query('SELECT * FROM eyn_inquiries ORDER BY id DESC')->fetchAll() : [];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel de Gestión | EYN LUXE</title>
  <style>
    body { margin:0; background:#0A0A0C; color:#F5F1E8; font-family:system-ui,sans-serif; }
    .wrap { max-width:1140px; margin:0 auto; padding:32px 20px; }
    .card { background:#131318; border:1px solid rgba(197,160,89,.28); border-radius:20px; padding:24px; margin-bottom:24px; }
    input,select,textarea { width:100%; box-sizing:border-box; padding:11px 13px; border-radius:10px; background:#0A0A0C; border:1px solid rgba(255,255,255,.15); color:#fff; margin-bottom:10px; }
    .btn { padding:11px 22px; border-radius:999px; border:none; background:#C5A059; color:#0A0A0C; font-weight:700; cursor:pointer; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th,td { text-align:left; padding:10px; border-bottom:1px solid rgba(255,255,255,.08); }
  </style>
</head>
<body>
<div class="wrap">
  <?php if (!$isLogged): ?>
    <div class="card" style="max-width:420px;margin:70px auto;">
      <h1 style="margin-top:0;color:#DFC286;">Gestión EYN LUXE</h1>
      <?php if ($error): ?><p style="color:#ef9a9a;font-size:13px;"><?= e($error) ?></p><?php endif; ?>
      <form method="post">
        <input type="hidden" name="action" value="login">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="email" name="email" required placeholder="Correo de administradora">
        <input type="password" name="password" required placeholder="Contraseña">
        <button type="submit" class="btn" style="width:100%">Iniciar Sesión</button>
      </form>
      <p style="margin-top:16px;font-size:12px;"><a href="index.php" style="color:#C5A059">← Volver a la web</a></p>
    </div>
  <?php else: ?>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <h1>Panel EYN LUXE · Estefanía Yáñez</h1>
      <div>
        <a href="index.php" style="color:#DFC286;margin-right:16px;">Ver Web</a>
        <a href="admin.php?logout=1" style="color:#ef9a9a;">Cerrar sesión</a>
      </div>
    </div>

    <?php if ($notice): ?><div class="card" style="border-color:#81c784;color:#c8e6c9;"><?= e($notice) ?></div><?php endif; ?>

    <div class="card">
      <h2>Publicar Nueva Propiedad</h2>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="create_property">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
          <input type="text" name="reference" required placeholder="Referencia (EYN-VLC-010)">
          <input type="text" name="title" required placeholder="Título del inmueble">
          <select name="operation">
            <option value="Comercialización Exclusiva">Comercialización Exclusiva</option>
            <option value="Venta">Venta</option>
            <option value="Alquiler">Alquiler</option>
            <option value="Construcción">Construcción</option>
          </select>
          <input type="text" name="zone" required placeholder="Zona en Valencia">
          <input type="number" name="price" placeholder="Precio numérico">
          <input type="text" name="price_label" placeholder="Etiqueta precio (ej. 1.450.000 €)">
          <input type="number" name="area_m2" placeholder="Superficie m²">
          <input type="number" name="bedrooms" placeholder="Dormitorios">
          <input type="number" name="bathrooms" placeholder="Baños">
        </div>
        <label style="font-size:12px;display:block;margin:6px 0;">Subir fotografía principal (JPG/PNG/WEBP):</label>
        <input type="file" name="photo" accept="image/*">
        <textarea name="description" rows="3" required placeholder="Descripción detallada..."></textarea>
        <label style="font-size:13px;display:block;margin-bottom:12px;">
          <input type="checkbox" name="featured" value="1" checked style="width:auto;"> Mostrar en Colección Exclusiva
        </label>
        <button type="submit" class="btn">Guardar Propiedad</button>
      </form>
    </div>

    <div class="card">
      <h2>Propiedades Activas (<?= count($props) ?>)</h2>
      <table>
        <thead><tr><th>Ref</th><th>Título</th><th>Operación</th><th>Precio</th><th>Acción</th></tr></thead>
        <tbody>
        <?php foreach ($props as $p): ?>
          <tr>
            <td><?= e($p['reference']) ?></td>
            <td><?= e($p['title']) ?></td>
            <td><?= e($p['operation']) ?></td>
            <td><?= e($p['price_label'] ?: (string)$p['price']) ?></td>
            <td>
              <form method="post" style="display:inline" onsubmit="return confirm('¿Eliminar propiedad?');">
                <input type="hidden" name="action" value="delete_property">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button type="submit" style="background:none;border:none;color:#ef9a9a;cursor:pointer;">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h2>Consultas Recibidas (<?= count($inquiries) ?>)</h2>
      <table>
        <thead><tr><th>Fecha</th><th>Cliente</th><th>Contacto</th><th>Servicio</th><th>Mensaje</th></tr></thead>
        <tbody>
        <?php foreach ($inquiries as $inq): ?>
          <tr>
            <td><?= e((string)$inq['created_at']) ?></td>
            <td><?= e($inq['full_name']) ?></td>
            <td><?= e($inq['phone']) ?><br><?= e($inq['email']) ?></td>
            <td><?= e($inq['service_type']) ?> <?= $inq['property_ref'] ? '(' . e($inq['property_ref']) . ')' : '' ?></td>
            <td><?= e($inq['message']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
