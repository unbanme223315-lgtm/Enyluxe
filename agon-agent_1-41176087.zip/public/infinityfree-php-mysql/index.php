<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$pdo = eyn_db();
$settings = eyn_load_settings($pdo);

// Procesamiento seguro del formulario de contacto / captación con CSRF y Honeypot
$formSuccess = false;
$formError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'contact') {
    if (!empty($_POST['website_hp'])) {
        $formSuccess = true; // Bot bloqueado silenciosamente
    } elseif (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $formError = 'La sesión del formulario ha caducado. Recargue la página e inténtelo de nuevo.';
    } else {
        $fullName = trim(strip_tags((string)($_POST['full_name'] ?? '')));
        $phone = trim(strip_tags((string)($_POST['phone'] ?? '')));
        $email = trim((string)($_POST['email'] ?? ''));
        $serviceType = trim(strip_tags((string)($_POST['service_type'] ?? 'Asesoramiento Personalizado')));
        $budget = trim(strip_tags((string)($_POST['budget_or_valuation'] ?? '')));
        $message = trim(strip_tags((string)($_POST['message'] ?? '')));
        $gdpr = !empty($_POST['gdpr_accepted']) ? 1 : 0;

        if (mb_strlen($fullName) < 2 || mb_strlen($phone) < 6) {
            $formError = 'Por favor, indique su nombre completo y un teléfono válido.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $formError = 'Por favor, facilite un correo electrónico válido.';
        } elseif (mb_strlen($message) < 8) {
            $formError = 'Por favor, describa brevemente su solicitud.';
        } elseif ($gdpr !== 1) {
            $formError = 'Debe aceptar la Política de Privacidad para enviar la consulta.';
        } else {
            $ins = $pdo->prepare(
                'INSERT INTO eyn_inquiries (full_name, phone, email, service_type, budget_or_valuation, message, gdpr_accepted, status)
                 VALUES (:full_name, :phone, :email, :service_type, :budget, :message, 1, "Nueva")'
            );
            $ins->execute([
                ':full_name' => mb_substr($fullName, 0, 120),
                ':phone' => mb_substr($phone, 0, 40),
                ':email' => mb_substr($email, 0, 150),
                ':service_type' => mb_substr($serviceType, 0, 80),
                ':budget' => mb_substr($budget, 0, 120),
                ':message' => mb_substr($message, 0, 2500),
            ]);
            $formSuccess = true;
        }
    }
}

// Filtros seguros del catálogo mediante PDO
$opFilter = trim((string)($_GET['operacion'] ?? 'Todas'));
$qFilter = trim((string)($_GET['q'] ?? ''));

$sql = 'SELECT * FROM eyn_properties WHERE status IN ("Disponible", "Reservado")';
$params = [];

if ($opFilter !== '' && $opFilter !== 'Todas') {
    $sql .= ' AND operation = :op';
    $params[':op'] = $opFilter;
}
if ($qFilter !== '') {
    $sql .= ' AND (title LIKE :q1 OR zone LIKE :q2 OR reference LIKE :q3)';
    $like = '%' . $qFilter . '%';
    $params[':q1'] = $like;
    $params[':q2'] = $like;
    $params[':q3'] = $like;
}
$sql .= ' ORDER BY sort_order ASC, id DESC';

$stmtProps = $pdo->prepare($sql);
$stmtProps->execute($params);
$properties = $stmtProps->fetchAll();

$stmtFeatured = $pdo->query('SELECT * FROM eyn_properties WHERE featured = 1 AND status IN ("Disponible", "Reservado") ORDER BY sort_order ASC LIMIT 4');
$featuredProps = $stmtFeatured->fetchAll();

$stmtFaqs = $pdo->query('SELECT * FROM eyn_faqs WHERE visible = 1 ORDER BY sort_order ASC');
$faqs = $stmtFaqs->fetchAll();

$services = [
    ['title' => 'Comercialización Exclusiva', 'desc' => 'Tu propiedad merece destacar, no solo anunciarse. Estrategia editorial, reportaje arquitectónico y filtrado riguroso.'],
    ['title' => 'Compra de Propiedades', 'desc' => 'Búsqueda personalizada en Valencia, acceso a viviendas singulares y defensa experta de sus intereses.'],
    ['title' => 'Venta Patrimonial', 'desc' => 'Valoración precisa, preparación estética y acompañamiento jurídico y documental hasta notaría.'],
    ['title' => 'Alquiler Exclusivo', 'desc' => 'Selección de arrendatarios altamente solventes y seguridad contractual integral para el propietario.'],
    ['title' => 'Construcción y Reforma', 'desc' => 'Proyectos residenciales de obra nueva e interiorismo llave en mano con control de calidades y plazos.'],
    ['title' => 'Asesoramiento Personalizado', 'desc' => 'Atención directa y confidencial liderada por Estefanía Yáñez en Valencia, España.'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($settings['brand_name']) ?> – <?= e($settings['brand_subtitle']) ?> | Valencia</title>
  <meta name="description" content="EYN LUXE – Exclusive Real Estate en Valencia, España. Compra, venta, alquiler, construcción y comercialización exclusiva con Estefanía Yáñez.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { --bg:#0A0A0C; --card:#131318; --gold:#C5A059; --gold-lt:#DFC286; --ivory:#F5F1E8; }
    * { box-sizing:border-box; margin:0; padding:0; }
    html { scroll-behavior:smooth; background:var(--bg); color:var(--ivory); font-family:'Plus Jakarta Sans',sans-serif; }
    a { color:inherit; text-decoration:none; }
    .serif { font-family:'Cormorant Garamond',Georgia,serif; }
    .container { max-width:1240px; margin:0 auto; padding:0 24px; }
    header { position:sticky; top:0; z-index:40; background:rgba(10,10,12,.9); backdrop-filter:blur(16px); border-bottom:1px solid rgba(197,160,89,.22); padding:16px 0; }
    .nav-row { display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap; }
    .nav-links { display:flex; gap:24px; font-size:12px; letter-spacing:.15em; text-transform:uppercase; }
    .btn-gold { display:inline-block; padding:12px 26px; border-radius:999px; background:linear-gradient(90deg,#C5A059,#DFC286,#A98237); color:#0A0A0C; font-weight:700; font-size:12px; letter-spacing:.15em; text-transform:uppercase; border:none; cursor:pointer; }
    .hero { min-height:84vh; display:flex; align-items:flex-end; padding:110px 0 72px; background:linear-gradient(180deg,rgba(10,10,12,.55),#0A0A0C), url('images/hero-villa.jpg') center/cover no-repeat; border-bottom:1px solid rgba(197,160,89,.25); }
    .hero h1 { font-size:clamp(2.5rem,6vw,5rem); line-height:1.04; color:#fff; max-width:820px; font-weight:400; }
    .arch-wrap { margin-top:32px; border-radius:72px 72px 0 0; border-top:1px solid rgba(223,194,134,.4); background:radial-gradient(ellipse at 50% 0%,rgba(197,160,89,.22),transparent 65%); padding:72px 0; }
    .grid-3 { display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:26px; }
    .card { background:var(--card); border:1px solid rgba(255,255,255,.1); border-radius:24px; overflow:hidden; transition:border-color .3s,transform .3s; }
    .card:hover { border-color:var(--gold); transform:translateY(-4px); }
    .card img { width:100%; height:240px; object-fit:cover; display:block; }
    .card-body { padding:24px; }
    .badge { display:inline-block; padding:5px 12px; border-radius:999px; background:rgba(197,160,89,.16); border:1px solid rgba(197,160,89,.45); color:var(--gold-lt); font-size:11px; text-transform:uppercase; letter-spacing:.14em; }
    input,select,textarea { width:100%; padding:13px 15px; border-radius:12px; background:#0A0A0C; border:1px solid rgba(255,255,255,.14); color:#fff; font-family:inherit; font-size:14px; }
    details { border-bottom:1px solid rgba(255,255,255,.12); padding:20px 0; }
    summary { cursor:pointer; font-size:22px; color:#fff; list-style:none; display:flex; justify-content:space-between; align-items:center; }
    footer { padding:60px 0 40px; }
    .footer-box { background:#0E0E13; border:1px solid rgba(197,160,89,.35); border-radius:30px; padding:44px; box-shadow:0 20px 80px rgba(197,160,89,.14); }
  </style>
</head>
<body>
<header>
  <div class="container nav-row">
    <a href="index.php" class="serif" style="font-size:26px;letter-spacing:.2em;color:#fff;">
      EYN <span style="color:var(--gold)">LUXE</span>
      <small style="display:block;font-family:'Plus Jakarta Sans',sans-serif;font-size:10px;letter-spacing:.26em;color:rgba(245,241,232,.65);">EXCLUSIVE REAL ESTATE · VALENCIA</small>
    </a>
    <nav class="nav-links">
      <a href="#coleccion">Colección</a>
      <a href="#catalogo">Propiedades</a>
      <a href="#servicios">Servicios</a>
      <a href="#faq">FAQ</a>
      <a href="#contacto">Contacto</a>
      <a href="admin.php" style="color:var(--gold-lt)">Gestión</a>
    </nav>
    <a href="#contacto" class="btn-gold">Contactar</a>
  </div>
</header>

<section class="hero">
  <div class="container">
    <p style="font-size:12px;letter-spacing:.24em;text-transform:uppercase;color:var(--gold-lt);margin-bottom:14px;">
      <?= e($settings['director_name']) ?> · <?= e($settings['location']) ?>
    </p>
    <h1 class="serif"><?= e($settings['hero_slogan']) ?></h1>
    <p style="margin-top:20px;font-size:18px;color:rgba(245,241,232,.82);max-width:620px;">
      «<?= e($settings['key_message']) ?>»
    </p>
    <div style="margin-top:28px;display:flex;gap:14px;flex-wrap:wrap;">
      <a href="#catalogo" class="btn-gold">Explorar Cartera</a>
      <a href="tel:+<?= e($settings['phone_clean']) ?>" style="padding:12px 24px;border-radius:999px;border:1px solid rgba(245,241,232,.35);font-size:12px;letter-spacing:.15em;text-transform:uppercase;">
        <?= e($settings['phone_display']) ?>
      </a>
    </div>
  </div>
</section>

<section id="coleccion" class="arch-wrap">
  <div class="container">
    <div style="text-align:center;margin-bottom:44px;">
      <span class="badge">Selección Destacada</span>
      <h2 class="serif" style="font-size:46px;color:#fff;font-weight:400;margin-top:12px;">Colección Exclusiva en Valencia</h2>
    </div>
    <div class="grid-3">
      <?php foreach ($featuredProps as $fp): ?>
        <article class="card">
          <a href="propiedad.php?id=<?= (int)$fp['id'] ?>">
            <img src="<?= e($fp['main_image']) ?>" alt="<?= e($fp['title']) ?>">
          </a>
          <div class="card-body">
            <span class="badge"><?= e($fp['operation']) ?></span>
            <h3 class="serif" style="font-size:26px;color:#fff;margin-top:12px;"><?= e($fp['title']) ?></h3>
            <p style="font-size:13px;color:var(--gold);margin-top:4px;"><?= e($fp['zone']) ?></p>
            <p class="serif" style="font-size:24px;color:var(--gold-lt);margin-top:12px;">
              <?= e($fp['price_label'] ?: number_format((float)$fp['price'], 0, ',', '.') . ' €') ?>
            </p>
            <p style="font-size:12px;color:rgba(245,241,232,.7);margin-top:10px;">
              <?= (int)$fp['area_m2'] ?> m² · <?= (int)$fp['bedrooms'] ?> Dorm. · <?= (int)$fp['bathrooms'] ?> Baños
            </p>
            <a href="propiedad.php?id=<?= (int)$fp['id'] ?>" style="display:inline-block;margin-top:16px;font-size:12px;letter-spacing:.15em;text-transform:uppercase;color:var(--gold-lt);font-weight:600;">
              Ver Ficha Completa ↗
            </a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="catalogo" style="padding:72px 0;border-top:1px solid rgba(255,255,255,.07);">
  <div class="container">
    <h2 class="serif" style="font-size:42px;color:#fff;font-weight:400;margin-bottom:24px;">Catálogo Inmobiliario</h2>
    <form method="get" action="#catalogo" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;background:var(--card);padding:20px;border-radius:20px;margin-bottom:36px;border:1px solid rgba(197,160,89,.25);">
      <select name="operacion">
        <?php foreach (['Todas', 'Venta', 'Alquiler', 'Construcción', 'Comercialización Exclusiva'] as $op): ?>
          <option value="<?= e($op) ?>" <?= $opFilter === $op ? 'selected' : '' ?>>Operación: <?= e($op) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="text" name="q" value="<?= e($qFilter) ?>" placeholder="Buscar zona, título o referencia...">
      <button type="submit" class="btn-gold">Filtrar Propiedades</button>
    </form>

    <div class="grid-3">
      <?php foreach ($properties as $prop): ?>
        <article class="card">
          <a href="propiedad.php?id=<?= (int)$prop['id'] ?>">
            <img src="<?= e($prop['main_image']) ?>" alt="<?= e($prop['title']) ?>">
          </a>
          <div class="card-body">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span class="badge"><?= e($prop['operation']) ?></span>
              <small style="color:rgba(245,241,232,.6)">Ref. <?= e($prop['reference']) ?></small>
            </div>
            <h3 class="serif" style="font-size:24px;color:#fff;margin-top:12px;"><?= e($prop['title']) ?></h3>
            <p style="font-size:13px;color:var(--gold);margin-top:4px;"><?= e($prop['zone']) ?></p>
            <p class="serif" style="font-size:23px;color:var(--gold-lt);margin-top:10px;">
              <?= e($prop['price_label'] ?: number_format((float)$prop['price'], 0, ',', '.') . ' €') ?>
            </p>
            <a href="propiedad.php?id=<?= (int)$prop['id'] ?>" style="display:inline-block;margin-top:14px;font-size:12px;text-transform:uppercase;letter-spacing:.14em;color:var(--gold-lt);">
              Abrir Dossier ↗
            </a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="servicios" style="padding:72px 0;border-top:1px solid rgba(255,255,255,.07);">
  <div class="container">
    <span class="badge">Servicios Integrales</span>
    <h2 class="serif" style="font-size:44px;color:#fff;font-weight:400;margin:12px 0 36px;">Soluciones a la Altura de su Patrimonio</h2>
    <div class="grid-3">
      <?php foreach ($services as $idx => $srv): ?>
        <div class="card" style="padding:30px;<?= $idx === 0 ? 'background:linear-gradient(135deg,#C8A45D,#8E6C2D);color:#0A0A0C;' : '' ?>">
          <h3 class="serif" style="font-size:28px;margin-bottom:12px;<?= $idx === 0 ? 'color:#0A0A0C;' : 'color:#fff;' ?>"><?= e($srv['title']) ?></h3>
          <p style="font-size:14px;line-height:1.65;<?= $idx === 0 ? 'color:#0A0A0C;' : 'color:rgba(245,241,232,.75);' ?>"><?= e($srv['desc']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="faq" style="padding:72px 0;border-top:1px solid rgba(255,255,255,.07);">
  <div class="container" style="max-width:860px;">
    <h2 class="serif" style="font-size:44px;color:#fff;text-align:center;font-weight:400;margin-bottom:32px;">Preguntas Frecuentes</h2>
    <?php foreach ($faqs as $faq): ?>
      <details>
        <summary class="serif"><?= e($faq['question']) ?> <span style="color:var(--gold)">+</span></summary>
        <p style="padding-top:12px;font-size:14px;line-height:1.7;color:rgba(245,241,232,.75);"><?= e($faq['answer']) ?></p>
      </details>
    <?php endforeach; ?>
  </div>
</section>

<section id="contacto" style="padding:72px 0;border-top:1px solid rgba(255,255,255,.07);">
  <div class="container" style="max-width:780px;">
    <h2 class="serif" style="font-size:44px;color:#fff;font-weight:400;margin-bottom:10px;">Contacto Privado y Captación</h2>
    <p style="font-size:14px;color:rgba(245,241,232,.72);margin-bottom:28px;">
      Atención directa con <?= e($settings['director_name']) ?> en <?= e($settings['location']) ?> · Tel. <?= e($settings['phone_display']) ?>
    </p>

    <?php if ($formSuccess): ?>
      <div style="padding:22px;border-radius:18px;background:rgba(197,160,89,.16);border:1px solid var(--gold);margin-bottom:24px;">
        <strong>Solicitud registrada correctamente.</strong> Nos pondremos en contacto con usted a la mayor brevedad.
      </div>
    <?php endif; ?>
    <?php if ($formError): ?>
      <div style="padding:16px;border-radius:14px;background:rgba(180,40,40,.25);border:1px solid #e57373;margin-bottom:20px;font-size:13px;">
        <?= e($formError) ?>
      </div>
    <?php endif; ?>

    <form method="post" action="#contacto" style="display:grid;gap:16px;background:var(--card);padding:32px;border-radius:24px;border:1px solid rgba(255,255,255,.1);">
      <input type="hidden" name="action" value="contact">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <input type="text" name="website_hp" style="display:none" tabindex="-1" autocomplete="off">

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">
        <input type="text" name="full_name" required placeholder="Nombre y apellidos *">
        <input type="tel" name="phone" required placeholder="Teléfono de contacto *">
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">
        <input type="email" name="email" required placeholder="Correo electrónico *">
        <select name="service_type">
          <option value="Comercialización Exclusiva">Comercialización Exclusiva</option>
          <option value="Compra">Compra de Propiedad</option>
          <option value="Venta">Venta de Propiedad</option>
          <option value="Alquiler">Alquiler Residencial</option>
          <option value="Construcción">Construcción y Reforma</option>
          <option value="Asesoramiento Personalizado">Asesoramiento Personalizado</option>
        </select>
      </div>
      <input type="text" name="budget_or_valuation" placeholder="Zona de interés o presupuesto orientativo">
      <textarea name="message" rows="4" required placeholder="Detalle su consulta o el inmueble que desea comercializar... *"></textarea>
      <label style="font-size:12px;color:rgba(245,241,232,.75);display:flex;gap:8px;align-items:flex-start;">
        <input type="checkbox" name="gdpr_accepted" value="1" required style="width:auto;margin-top:3px;">
        <span>Acepto el tratamiento confidencial de mis datos conforme al RGPD por parte de EYN LUXE – Exclusive Real Estate.</span>
      </label>
      <button type="submit" class="btn-gold">Enviar Solicitud Confidencial</button>
    </form>
  </div>
</section>

<footer>
  <div class="container">
    <div class="footer-box">
      <div class="nav-row">
        <div>
          <p class="serif" style="font-size:34px;letter-spacing:.18em;color:#fff;">EYN <span style="color:var(--gold)">LUXE</span></p>
          <p style="font-size:13px;color:rgba(245,241,232,.7);margin-top:6px;">
            <?= e($settings['director_name']) ?> · <?= e($settings['location']) ?> · <a href="tel:+<?= e($settings['phone_clean']) ?>" style="color:var(--gold-lt)"><?= e($settings['phone_display']) ?></a>
          </p>
        </div>
        <a href="https://wa.me/<?= e($settings['phone_clean']) ?>" target="_blank" rel="noopener" class="btn-gold">WhatsApp Directo</a>
      </div>
      <p style="margin-top:28px;padding-top:20px;border-top:1px solid rgba(255,255,255,.1);font-size:12px;color:rgba(245,241,232,.5);">
        © <?= date('Y') ?> EYN LUXE – Exclusive Real Estate. Todos los derechos reservados.
      </p>
    </div>
  </div>
</footer>
</body>
</html>
