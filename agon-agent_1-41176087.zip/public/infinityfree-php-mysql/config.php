<?php
declare(strict_types=1);

/**
 * EYN LUXE – Exclusive Real Estate (Valencia, España)
 * Archivo de configuración segura PHP 8 + MySQL compatible con InfinityFree
 *
 * INSTRUCCIONES EN INFINITYFREE:
 * Rellene DB_HOST, DB_NAME, DB_USER y DB_PASS con los datos que aparecen en
 * su panel de InfinityFree -> "MySQL Databases".
 */

define('DB_HOST', 'sqlXXX.infinityfree.com'); // Ej: sql204.infinityfree.com
define('DB_NAME', 'if0_XXXXXXXX_eynluxe');    // Ej: if0_38123456_eynluxe
define('DB_USER', 'if0_XXXXXXXX');            // Su MySQL Username de InfinityFree
define('DB_PASS', 'SU_CONTRASENA_MYSQL');     // Su MySQL Password de InfinityFree

// Cabeceras de seguridad HTTP compatibles con hosting compartido
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Configuración segura de sesión PHP
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/**
 * Obtiene la conexión PDO única con utf8mb4 y sentencias preparadas nativas.
 */
function eyn_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    return $pdo;
}

/**
 * Escapado seguro contra XSS para todo texto mostrado en HTML.
 */
function e(?string $value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Generación y verificación de token CSRF para formularios públicos y privados.
 */
function csrf_token(): string
{
    if (empty($_SESSION['eyn_csrf'])) {
        $_SESSION['eyn_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['eyn_csrf'];
}

function verify_csrf(?string $token): bool
{
    if (empty($_SESSION['eyn_csrf']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['eyn_csrf'], $token);
}

/**
 * Carga la tabla de ajustes corporativos en un array asociativo.
 */
function eyn_load_settings(PDO $pdo): array
{
    $defaults = [
        'brand_name' => 'EYN LUXE',
        'brand_subtitle' => 'Exclusive Real Estate',
        'director_name' => 'Estefanía Yáñez',
        'location' => 'Valencia, España',
        'phone_display' => '+34 658 659 387',
        'phone_clean' => '34658659387',
        'corporate_email' => '',
        'postal_address' => 'Valencia, España (Cita previa)',
        'hero_slogan' => 'Propiedades exclusivas para personas excepcionales.',
        'key_message' => 'Tu propiedad merece destacar, no solo anunciarse.',
    ];

    try {
        $stmt = $pdo->query('SELECT setting_key, setting_value FROM eyn_settings');
        foreach ($stmt->fetchAll() as $row) {
            $defaults[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Throwable $e) {
        // Mantiene valores por defecto si la tabla aún no se ha importado
    }
    return $defaults;
}
