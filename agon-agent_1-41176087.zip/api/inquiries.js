import supabase from './db-client.js';

async function verifyAdmin(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return null;
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return null;
  return data.user;
}

function sanitizeText(val, maxLen = 1000) {
  return String(val || '')
    .replace(/[<>]/g, '')
    .trim()
    .slice(0, maxLen);
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const body = req.body || {};
      // Honeypot check against automated bots
      if (body.website_hp) {
        return res.status(200).json({ ok: true });
      }

      const full_name = sanitizeText(body.full_name, 120);
      const phone = sanitizeText(body.phone, 40);
      const email = sanitizeText(body.email, 150);
      const service_type = sanitizeText(body.service_type || 'Asesoramiento Personalizado', 80);
      const message = sanitizeText(body.message, 2500);
      const gdpr_accepted = Boolean(body.gdpr_accepted);

      if (!full_name || full_name.length < 2) {
        return res.status(400).json({ error: 'Por favor, indique su nombre completo.' });
      }
      if (!phone || phone.length < 6) {
        return res.status(400).json({ error: 'Por favor, facilite un teléfono válido de contacto.' });
      }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ error: 'Por favor, introduzca un correo electrónico válido.' });
      }
      if (!message || message.length < 8) {
        return res.status(400).json({ error: 'Por favor, detalle brevemente su consulta o necesidad.' });
      }
      if (!gdpr_accepted) {
        return res.status(400).json({ error: 'Es necesario aceptar la Política de Privacidad para enviar su solicitud.' });
      }

      const payload = {
        full_name,
        phone,
        email,
        service_type,
        property_id: body.property_id ? Number(body.property_id) : null,
        property_ref: sanitizeText(body.property_ref || '', 50),
        preferred_contact: sanitizeText(body.preferred_contact || 'Teléfono / WhatsApp', 50),
        budget_or_valuation: sanitizeText(body.budget_or_valuation || '', 120),
        message,
        gdpr_accepted: true,
        status: 'Nueva',
        admin_notes: '',
      };

      const { data, error } = await supabase
        .from('eyn_inquiries')
        .insert(payload)
        .select('*')
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    const user = await verifyAdmin(req);
    if (!user) {
      return res.status(401).json({ error: 'No autorizado' });
    }

    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('eyn_inquiries')
        .select('*')
        .order('id', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'PUT') {
      const { id, status, admin_notes } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID requerido' });
      const { data, error } = await supabase
        .from('eyn_inquiries')
        .update({
          status: sanitizeText(status || 'En gestión', 40),
          admin_notes: sanitizeText(admin_notes || '', 2000),
        })
        .eq('id', id)
        .select('*')
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID requerido' });
      const { error } = await supabase.from('eyn_inquiries').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Método no permitido' });
  } catch (err) {
    console.error('API inquiries error:', err);
    return res.status(500).json({ error: err.message || 'Error interno del servidor' });
  }
}
