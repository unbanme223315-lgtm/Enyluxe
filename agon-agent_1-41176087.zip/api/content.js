import supabase from './db-client.js';

async function verifyAdmin(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return null;
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return null;
  return data.user;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { include_hidden } = req.query || {};
      let faqQuery = supabase.from('eyn_faqs').select('*').order('sort_order', { ascending: true }).order('id', { ascending: true });
      let testQuery = supabase.from('eyn_testimonials').select('*').order('sort_order', { ascending: true }).order('id', { ascending: true });
      const settingsQuery = supabase.from('eyn_settings').select('*');

      if (include_hidden !== 'true') {
        faqQuery = faqQuery.eq('visible', true);
        testQuery = testQuery.eq('visible', true);
      }

      const [faqsRes, testRes, settingsRes] = await Promise.all([
        faqQuery,
        testQuery,
        settingsQuery,
      ]);

      if (faqsRes.error) throw faqsRes.error;
      if (testRes.error) throw testRes.error;
      if (settingsRes.error) throw settingsRes.error;

      const settingsMap = {};
      for (const row of settingsRes.data || []) {
        settingsMap[row.setting_key] = row.setting_value;
      }

      return res.status(200).json({
        faqs: faqsRes.data || [],
        testimonials: testRes.data || [],
        settings: settingsMap,
      });
    }

    const user = await verifyAdmin(req);
    if (!user) return res.status(401).json({ error: 'No autorizado' });

    const { entity } = req.body || {};

    if (req.method === 'POST') {
      if (entity === 'faq') {
        const { question, answer, category, sort_order } = req.body;
        const { data, error } = await supabase
          .from('eyn_faqs')
          .insert({
            question: String(question || '').trim(),
            answer: String(answer || '').trim(),
            category: String(category || 'General').trim(),
            sort_order: Number(sort_order) || 10,
            visible: true,
          })
          .select('*')
          .single();
        if (error) throw error;
        return res.status(201).json(data);
      }

      if (entity === 'testimonial') {
        const { client_name, client_role, avatar_url, quote, operation_tag, sort_order } = req.body;
        const { data, error } = await supabase
          .from('eyn_testimonials')
          .insert({
            client_name: String(client_name || '').trim(),
            client_role: String(client_role || '').trim(),
            avatar_url: String(avatar_url || '/images/avatar-1.jpg').trim(),
            quote: String(quote || '').trim(),
            operation_tag: String(operation_tag || 'Comercialización Exclusiva').trim(),
            sort_order: Number(sort_order) || 10,
            visible: true,
          })
          .select('*')
          .single();
        if (error) throw error;
        return res.status(201).json(data);
      }
    }

    if (req.method === 'PUT') {
      if (entity === 'settings') {
        const { settings } = req.body || {};
        if (!settings || typeof settings !== 'object') {
          return res.status(400).json({ error: 'Objeto settings inválido' });
        }
        for (const [k, v] of Object.entries(settings)) {
          const { data: existing } = await supabase
            .from('eyn_settings')
            .select('id')
            .eq('setting_key', k)
            .limit(1);
          if (existing && existing.length > 0) {
            await supabase
              .from('eyn_settings')
              .update({ setting_value: String(v ?? '') })
              .eq('id', existing[0].id);
          } else {
            await supabase
              .from('eyn_settings')
              .insert({ setting_key: k, setting_value: String(v ?? '') });
          }
        }
        return res.status(200).json({ ok: true });
      }

      if (entity === 'faq') {
        const { id, ...fields } = req.body;
        delete fields.entity;
        const { data, error } = await supabase.from('eyn_faqs').update(fields).eq('id', id).select('*').single();
        if (error) throw error;
        return res.status(200).json(data);
      }

      if (entity === 'testimonial') {
        const { id, ...fields } = req.body;
        delete fields.entity;
        const { data, error } = await supabase.from('eyn_testimonials').update(fields).eq('id', id).select('*').single();
        if (error) throw error;
        return res.status(200).json(data);
      }
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      const table = entity === 'faq' ? 'eyn_faqs' : entity === 'testimonial' ? 'eyn_testimonials' : null;
      if (!table || !id) return res.status(400).json({ error: 'Parámetros inválidos' });
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(400).json({ error: 'Petición no reconocida' });
  } catch (err) {
    console.error('API content error:', err);
    return res.status(500).json({ error: err.message || 'Error interno' });
  }
}
