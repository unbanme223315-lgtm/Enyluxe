import supabase from './db-client.js';

async function verifyAdmin(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return null;
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user) return null;
  return data.user;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { operation, zone, featured, search, include_all } = req.query || {};
      let query = supabase
        .from('eyn_properties')
        .select('*')
        .order('sort_order', { ascending: true })
        .order('id', { ascending: false });

      if (include_all !== 'true') {
        query = query.in('status', ['Disponible', 'Reservado']);
      }
      if (operation && operation !== 'Todas') {
        query = query.eq('operation', operation);
      }
      if (zone && zone !== 'Todas') {
        query = query.ilike('zone', `%${zone}%`);
      }
      if (featured === 'true') {
        query = query.eq('featured', true);
      }
      if (search && String(search).trim()) {
        const term = String(search).trim();
        query = query.or(`title.ilike.%${term}%,zone.ilike.%${term}%,reference.ilike.%${term}%,description.ilike.%${term}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    const user = await verifyAdmin(req);
    if (!user) {
      return res.status(401).json({ error: 'No autorizado. Inicie sesión en el panel de gestión.' });
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.title || !body.reference || !body.zone) {
        return res.status(400).json({ error: 'Título, referencia y zona son obligatorios.' });
      }
      const slug = String(body.slug || body.title)
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      const payload = {
        reference: String(body.reference).trim(),
        slug: `${slug}-${Date.now().toString().slice(-4)}`,
        title: String(body.title).trim(),
        subtitle: String(body.subtitle || '').trim(),
        operation: body.operation || 'Venta',
        property_type: body.property_type || 'Vivienda Exclusiva',
        zone: String(body.zone).trim(),
        city: String(body.city || 'Valencia').trim(),
        price: Number(body.price) || 0,
        price_label: String(body.price_label || '').trim(),
        area_m2: Number(body.area_m2) || 0,
        plot_m2: Number(body.plot_m2) || 0,
        bedrooms: Number(body.bedrooms) || 0,
        bathrooms: Number(body.bathrooms) || 0,
        energy_rating: String(body.energy_rating || 'A').trim(),
        featured: Boolean(body.featured),
        exclusive_badge: body.exclusive_badge !== false,
        status: body.status || 'Disponible',
        description: String(body.description || '').trim(),
        highlights: Array.isArray(body.highlights) ? body.highlights : [],
        main_image: String(body.main_image || '/images/hero-villa.jpg').trim(),
        gallery: Array.isArray(body.gallery) ? body.gallery : [],
        sort_order: Number(body.sort_order) || 10,
      };

      const { data, error } = await supabase
        .from('eyn_properties')
        .insert(payload)
        .select('*')
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID de propiedad requerido.' });

      const cleanUpdates = { ...updates };
      delete cleanUpdates.created_at;

      const { data, error } = await supabase
        .from('eyn_properties')
        .update(cleanUpdates)
        .eq('id', id)
        .select('*')
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID requerido.' });
      const { error } = await supabase.from('eyn_properties').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Método no permitido' });
  } catch (err) {
    console.error('API properties error:', err);
    return res.status(500).json({ error: err.message || 'Error interno del servidor' });
  }
}
