export interface Property {
  id: number;
  reference: string;
  slug: string;
  title: string;
  subtitle: string;
  operation: 'Venta' | 'Alquiler' | 'Construcción' | 'Comercialización Exclusiva' | string;
  property_type: string;
  zone: string;
  city: string;
  price: number;
  price_label: string;
  area_m2: number;
  plot_m2: number;
  bedrooms: number;
  bathrooms: number;
  energy_rating: string;
  featured: boolean;
  exclusive_badge: boolean;
  status: 'Disponible' | 'Reservado' | 'Vendido' | string;
  description: string;
  highlights: string[];
  main_image: string;
  gallery: string[];
  sort_order: number;
  created_at?: string;
}

export interface Inquiry {
  id: number;
  full_name: string;
  phone: string;
  email: string;
  service_type: string;
  property_id: number | null;
  property_ref: string;
  preferred_contact: string;
  budget_or_valuation: string;
  message: string;
  gdpr_accepted: boolean;
  status: 'Nueva' | 'En gestión' | 'Atendida' | string;
  admin_notes: string;
  created_at?: string;
}

export interface Testimonial {
  id: number;
  client_name: string;
  client_role: string;
  avatar_url: string;
  quote: string;
  operation_tag: string;
  visible: boolean;
  sort_order: number;
}

export interface FaqItem {
  id: number;
  question: string;
  answer: string;
  category: string;
  sort_order: number;
  visible: boolean;
}

export interface SiteSettings {
  brand_name?: string;
  brand_subtitle?: string;
  director_name?: string;
  location?: string;
  phone_display?: string;
  phone_clean?: string;
  corporate_email?: string;
  postal_address?: string;
  legal_id_note?: string;
  hero_slogan?: string;
  key_message?: string;
  instagram_url?: string;
  linkedin_url?: string;
  [key: string]: string | undefined;
}
