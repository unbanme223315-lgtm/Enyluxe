import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

interface PrimeZonesProps {
  onSelectZone: (zoneKeyword: string) => void;
}

const ZONES = [
  {
    name: 'El Pla del Real & Paseo de la Alameda',
    filterKey: 'Pla del Real',
    tag: 'VALENCIA · VISTAS A JARDINES DEL TURIA',
    image: '/images/penthouse-turia.jpg',
    summary: 'Áticos señoriales y grandes pisos representativos junto al cauce histórico del Turia.',
  },
  {
    name: 'Ciutat Vella, La Xerea & Eixample',
    filterKey: 'Ciutat Vella',
    tag: 'PATRIMONIO HISTÓRICO · ARQUITECTURA NOBLE',
    image: '/images/valencia-historic.jpg',
    summary: 'Rehabilitaciones exclusivas, techos altos y residencias con carácter en el corazón de Valencia.',
  },
  {
    name: 'Cortes Valencianas & Ciudad de las Artes',
    filterKey: 'Cortes Valencianas',
    tag: 'VANGUARDIA · OBRA NUEVA Y SKYLINE',
    image: '/images/valencia-arts.jpg',
    summary: 'Complejos contemporáneos con terrazas panorámicas, seguridad 24 h y eficiencia energética A.',
  },
  {
    name: 'Los Monasterios, Campolivar & Costa',
    filterKey: 'Monasterios',
    tag: 'VILLAS PRIVADAS · MEDITERRÁNEO Y NATURALEZA',
    image: '/images/valencia-coast.jpg',
    summary: 'Villas independientes sobre parcelas ajardinadas y residencias frente al mar Mediterráneo.',
  },
];

export default function PrimeZones({ onSelectZone }: PrimeZonesProps) {
  const [hoveredIdx, setHoveredIdx] = useState<number>(0);

  return (
    <section
      id="zonas"
      className="py-24 md:py-32 bg-[#0A0A0C] border-t border-white/[0.06]"
      aria-labelledby="zonas-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-14 md:mb-18">
          <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-3">
            Ubicaciones Seleccionadas
          </p>
          <h2
            id="zonas-heading"
            className="font-serif-luxe text-4xl sm:text-5xl md:text-6xl text-white font-normal leading-[1.06]"
          >
            Enclaves Prime y <br />
            <span className="italic text-[#DFC286]">Presencia en Valencia</span>
          </h2>
        </div>

        {/* Interactive Horizontal Hairline Rows with Floating Right Image Preview (Reference Frames 16-17) */}
        <div className="relative border-t border-white/12">
          {ZONES.map((zone, idx) => {
            const isHovered = hoveredIdx === idx;
            return (
              <div
                key={zone.name}
                onMouseEnter={() => setHoveredIdx(idx)}
                onClick={() => onSelectZone(zone.filterKey)}
                className="group relative border-b border-white/12 py-7 sm:py-9 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer transition-colors hover:bg-white/[0.015] px-2 sm:px-4"
              >
                <div className="max-w-xl">
                  <div className="flex items-center gap-3">
                    <h3
                      className={`font-serif-luxe text-2xl sm:text-3xl md:text-4xl transition-colors duration-300 ${
                        isHovered ? 'text-[#DFC286]' : 'text-white'
                      }`}
                    >
                      {zone.name}
                    </h3>
                    <ArrowUpRight
                      className={`w-5 h-5 transition-all duration-300 ${
                        isHovered
                          ? 'text-[#DFC286] translate-x-0.5 -translate-y-0.5 opacity-100'
                          : 'text-white/30 opacity-0'
                      }`}
                    />
                  </div>
                  <p className="text-xs sm:text-sm text-[#F5F1E8]/60 mt-1.5">{zone.summary}</p>
                </div>

                {/* Floating Image Preview on Desktop + Tag on Right */}
                <div className="flex items-center gap-6">
                  <div className="hidden lg:block relative w-52 h-28 pointer-events-none">
                    <AnimatePresence>
                      {isHovered && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.9, rotate: -2 }}
                          animate={{ opacity: 1, scale: 1, rotate: 0 }}
                          exit={{ opacity: 0, scale: 0.92 }}
                          transition={{ duration: 0.3 }}
                          className="absolute -top-6 inset-x-0 h-36 rounded-2xl overflow-hidden border border-[#C5A059]/50 shadow-[0_20px_50px_rgba(0,0,0,0.85)] z-20"
                        >
                          <img
                            src={zone.image}
                            alt={zone.name}
                            className="w-full h-full object-cover"
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <span
                    className={`text-[11px] sm:text-xs uppercase tracking-[0.2em] font-medium transition-colors ${
                      isHovered ? 'text-[#C5A059]' : 'text-[#F5F1E8]/55'
                    }`}
                  >
                    {zone.tag}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
