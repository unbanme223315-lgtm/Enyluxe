import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight, BedDouble, Bath, Maximize2, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import type { Property } from '../types/eyn';

interface ExclusiveShowcaseProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  keyMessage: string;
}

export default function ExclusiveShowcase({
  properties,
  onSelectProperty,
  keyMessage,
}: ExclusiveShowcaseProps) {
  const featuredList = properties.filter((p) => p.featured).slice(0, 5);
  const items = featuredList.length > 0 ? featuredList : properties.slice(0, 4);
  const [activeIndex, setActiveIndex] = useState(0);

  if (items.length === 0) return null;

  const current = items[activeIndex] || items[0];
  const progressPct = ((activeIndex + 1) / items.length) * 100;

  const formatPrice = (prop: Property) => {
    if (prop.price_label) return prop.price_label;
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(prop.price);
  };

  return (
    <section
      id="coleccion"
      className="relative pt-12 pb-24 md:pb-32 bg-[#0A0A0C] overflow-hidden"
      aria-labelledby="coleccion-heading"
    >
      {/* Reference Video Frames 04-08: Curved Glowing Gold Horizon Arch */}
      <div className="relative mx-auto max-w-[1680px]">
        <div
          className="absolute -top-6 inset-x-[-12%] h-[420px] rounded-t-[100%] pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 75% 58% at 50% 0%, rgba(197,160,89,0.42) 0%, rgba(152,116,48,0.18) 42%, rgba(10,10,12,0) 78%)',
          }}
        />
        <div className="relative rounded-t-[48px] sm:rounded-t-[80px] md:rounded-t-[120px] border-t border-[#DFC286]/35 bg-gradient-to-b from-[#1B160E]/90 via-[#101014] to-[#0A0A0C] pt-16 sm:pt-24 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Section Header */}
            <div className="text-center max-w-3xl mx-auto mb-14 md:mb-20">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#C5A059]/35 bg-[#C5A059]/10 mb-4">
                <Sparkles className="w-3.5 h-3.5 text-[#DFC286]" />
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#DFC286]">
                  Cartera Selecta · Valencia
                </span>
              </div>
              <h2
                id="coleccion-heading"
                className="font-serif-luxe text-4xl sm:text-5xl md:text-6xl text-white font-normal tracking-tight"
              >
                Colección Exclusiva
              </h2>
              <p className="mt-4 text-sm sm:text-base text-[#F5F1E8]/75 font-light italic font-serif-luxe text-xl">
                «{keyMessage}»
              </p>
            </div>

            {/* 2-Column Split: Left Vertical Timeline Rail + Right Stacked Property Card */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              {/* Left Vertical Selector matching Reference Frame 06-08 */}
              <div className="lg:col-span-5 relative pl-7 sm:pl-9">
                {/* Vertical progress rail */}
                <div className="absolute left-2 top-2 bottom-2 w-[2px] bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="w-full bg-gradient-to-b from-[#DFC286] to-[#C5A059] rounded-full"
                    animate={{ height: `${progressPct}%` }}
                    transition={{ duration: 0.45, ease: 'easeOut' }}
                  />
                </div>

                <div className="space-y-6 sm:space-y-8">
                  {items.map((prop, idx) => {
                    const isActive = idx === activeIndex;
                    return (
                      <button
                        key={prop.id}
                        type="button"
                        onClick={() => setActiveIndex(idx)}
                        className={`group relative w-full text-left transition-all duration-300 cursor-pointer ${
                          isActive ? 'opacity-100' : 'opacity-45 hover:opacity-80'
                        }`}
                      >
                        {/* Timeline dot */}
                        <span
                          className={`absolute -left-[27px] sm:-left-[35px] top-2.5 w-3.5 h-3.5 rounded-full border transition-all duration-300 ${
                            isActive
                              ? 'bg-[#DFC286] border-[#DFC286] scale-110 shadow-[0_0_14px_rgba(223,194,134,0.85)]'
                              : 'bg-[#0A0A0C] border-white/30 group-hover:border-[#C5A059]'
                          }`}
                        />

                        <h3 className="font-serif-luxe text-2xl sm:text-3xl text-white leading-snug group-hover:text-[#DFC286] transition-colors">
                          {prop.title}
                        </h3>
                        <p className="mt-1 text-xs sm:text-sm text-[#F5F1E8]/70 tracking-wide">
                          {prop.zone} <span className="text-[#C5A059] mx-1.5">•</span> {prop.operation}
                        </p>
                      </button>
                    );
                  })}
                </div>

                {/* Prev / Next Controls */}
                <div className="mt-8 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveIndex((prev) => (prev - 1 + items.length) % items.length)}
                    className="w-10 h-10 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
                    aria-label="Propiedad anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveIndex((prev) => (prev + 1) % items.length)}
                    className="w-10 h-10 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
                    aria-label="Propiedad siguiente"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <span className="text-xs uppercase tracking-[0.2em] text-[#F5F1E8]/55 ml-2">
                    0{activeIndex + 1} / 0{items.length}
                  </span>
                </div>
              </div>

              {/* Right Stacked Visual Showcase Card */}
              <div className="lg:col-span-7">
                <div className="relative h-[420px] sm:h-[510px] rounded-[28px] overflow-hidden border border-[#C5A059]/30 bg-[#141418] shadow-[0_30px_80px_rgba(0,0,0,0.75)]">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={current.id}
                      initial={{ opacity: 0, scale: 1.04, y: 18 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.98, y: -12 }}
                      transition={{ duration: 0.48, ease: [0.22, 1, 0.36, 1] }}
                      onClick={() => onSelectProperty(current)}
                      className="relative w-full h-full cursor-pointer group"
                    >
                      <img
                        src={current.main_image}
                        alt={current.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C] via-[#0A0A0C]/35 to-transparent" />

                      {/* Top Badges */}
                      <div className="absolute top-5 left-5 right-5 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-3.5 py-1.5 rounded-full bg-[#0A0A0C]/80 backdrop-blur-md border border-[#C5A059]/50 text-[11px] uppercase tracking-[0.16em] text-[#DFC286] font-medium">
                            {current.operation}
                          </span>
                          <span className="px-3 py-1.5 rounded-full bg-[#0A0A0C]/70 backdrop-blur-md text-[11px] tracking-[0.14em] text-[#F5F1E8]/85">
                            Ref. {current.reference}
                          </span>
                        </div>
                        <span className="px-4 py-1.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold tracking-wider">
                          {formatPrice(current)}
                        </span>
                      </div>

                      {/* Bottom Details & CTA */}
                      <div className="absolute bottom-0 inset-x-0 p-6 sm:p-8 flex flex-col sm:flex-row sm:items-end justify-between gap-5">
                        <div>
                          <p className="text-xs uppercase tracking-[0.2em] text-[#DFC286] mb-1">
                            {current.zone}
                          </p>
                          <h4 className="font-serif-luxe text-2xl sm:text-4xl text-white leading-tight">
                            {current.title}
                          </h4>
                          <div className="mt-3 flex flex-wrap items-center gap-4 text-xs sm:text-sm text-[#F5F1E8]/85">
                            <span className="flex items-center gap-1.5">
                              <Maximize2 className="w-4 h-4 text-[#C5A059]" /> {current.area_m2} m²
                            </span>
                            {current.bedrooms > 0 && (
                              <span className="flex items-center gap-1.5">
                                <BedDouble className="w-4 h-4 text-[#C5A059]" /> {current.bedrooms} Dorm.
                              </span>
                            )}
                            {current.bathrooms > 0 && (
                              <span className="flex items-center gap-1.5">
                                <Bath className="w-4 h-4 text-[#C5A059]" /> {current.bathrooms} Baños
                              </span>
                            )}
                          </div>
                        </div>

                        <span className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[#F5F1E8] text-[#0A0A0C] text-xs font-semibold uppercase tracking-[0.15em] group-hover:bg-[#DFC286] transition-colors shrink-0">
                          Ver Dossier <ArrowUpRight className="w-4 h-4" />
                        </span>
                      </div>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
