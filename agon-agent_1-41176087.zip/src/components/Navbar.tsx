import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Heart, Phone, Lock, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface NavbarProps {
  favoritesCount: number;
  onOpenFavorites: () => void;
  onScrollToContact: (preselectedService?: string) => void;
  phoneDisplay: string;
  phoneClean: string;
}

const NAV_ITEMS = [
  { label: 'Colección', href: '#coleccion' },
  { label: 'Propiedades', href: '#catalogo' },
  { label: 'Por qué EYN LUXE', href: '#por-que' },
  { label: 'Servicios', href: '#servicios' },
  { label: 'Zonas', href: '#zonas' },
  { label: 'FAQ', href: '#faq' },
];

export default function Navbar({
  favoritesCount,
  onOpenFavorites,
  onScrollToContact,
  phoneDisplay,
  phoneClean,
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 36);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-[#0A0A0C]/88 backdrop-blur-xl border-b border-[#C5A059]/18 py-3.5'
            : 'bg-gradient-to-b from-[#0A0A0C]/85 via-[#0A0A0C]/40 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <a
            href="#inicio"
            className="group flex items-center gap-3.5 focus:outline-none"
            aria-label="EYN LUXE – Exclusive Real Estate Inicio"
          >
            <div className="w-10 h-10 rounded-full border border-[#C5A059]/60 bg-[#121216]/90 flex items-center justify-center shadow-[0_0_24px_rgba(197,160,89,0.16)] group-hover:border-[#DFC286] transition-colors">
              <span className="font-serif-luxe text-lg font-semibold tracking-wider text-[#DFC286]">
                EYN
              </span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif-luxe text-xl sm:text-2xl tracking-[0.22em] text-white font-medium leading-none">
                EYN <span className="text-[#C5A059]">LUXE</span>
              </span>
              <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.28em] text-[#F5F1E8]/65 mt-1">
                Exclusive Real Estate
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-7" aria-label="Navegación principal">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-xs uppercase tracking-[0.16em] text-[#F5F1E8]/75 hover:text-[#DFC286] transition-colors duration-300"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="hidden md:flex items-center gap-3">
            <button
              type="button"
              onClick={onOpenFavorites}
              className="relative w-10 h-10 rounded-full border border-white/12 bg-white/[0.03] hover:border-[#C5A059]/60 hover:text-[#DFC286] flex items-center justify-center text-[#F5F1E8]/80 transition-all cursor-pointer"
              aria-label="Propiedades guardadas en favoritos"
              title="Selección guardada"
            >
              <Heart className="w-4 h-4" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4.5 h-4.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-[10px] font-bold flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </button>

            <Link
              to="/admin"
              className="w-10 h-10 rounded-full border border-white/12 bg-white/[0.03] hover:border-[#C5A059]/60 hover:text-[#DFC286] flex items-center justify-center text-[#F5F1E8]/70 transition-all"
              aria-label="Panel de gestión privada"
              title="Acceso Gestión EYN LUXE"
            >
              <Lock className="w-3.5 h-3.5" />
            </Link>

            {/* Dual-Slide Pill Button inspired by reference video */}
            <button
              type="button"
              onClick={() => onScrollToContact()}
              className="eyn-pill-btn h-10 px-6 rounded-full bg-gradient-to-r from-[#C5A059] via-[#D4B36F] to-[#B48D42] text-[#0A0A0C] font-semibold text-xs uppercase tracking-[0.16em] shadow-[0_0_28px_rgba(197,160,89,0.28)] hover:shadow-[0_0_36px_rgba(197,160,89,0.48)] transition-shadow cursor-pointer"
            >
              <span className="eyn-pill-track h-20">
                <span className="h-10 flex items-center justify-center gap-1.5">
                  Contactar <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
                <span className="h-10 flex items-center justify-center gap-1.5">
                  Atención Privada <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </span>
            </button>
          </div>

          {/* Mobile Trigger */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              type="button"
              onClick={onOpenFavorites}
              className="relative w-10 h-10 rounded-full border border-white/15 bg-[#131318]/80 flex items-center justify-center text-[#F5F1E8]"
              aria-label="Favoritos"
            >
              <Heart className="w-4 h-4" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#C5A059] text-[#0A0A0C] text-[10px] font-bold flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              className="w-10 h-10 rounded-full border border-[#C5A059]/45 bg-[#131318]/90 flex items-center justify-center text-[#DFC286]"
              aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
              aria-expanded={mobileOpen}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fullscreen Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.28 }}
            className="fixed inset-0 z-40 bg-[#0A0A0C]/98 backdrop-blur-2xl pt-24 pb-10 px-6 flex flex-col justify-between overflow-y-auto md:hidden"
          >
            <nav className="flex flex-col divide-y divide-white/10">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="py-4 font-serif-luxe text-2xl text-[#F5F1E8] hover:text-[#C5A059] flex items-center justify-between transition-colors"
                >
                  <span>{item.label}</span>
                  <ArrowUpRight className="w-5 h-5 text-[#C5A059]" />
                </a>
              ))}
              <Link
                to="/admin"
                onClick={() => setMobileOpen(false)}
                className="py-4 text-sm uppercase tracking-[0.18em] text-[#F5F1E8]/70 hover:text-[#C5A059] flex items-center gap-2"
              >
                <Lock className="w-4 h-4 text-[#C5A059]" /> Acceso Gestión Privada
              </Link>
            </nav>

            <div className="mt-8 space-y-4 border-t border-[#C5A059]/20 pt-6">
              <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059]">
                Estefanía Yáñez · Valencia, España
              </p>
              <a
                href={`tel:+${phoneClean}`}
                className="flex items-center justify-center gap-2 w-full py-3.5 rounded-full border border-[#C5A059]/50 text-[#F5F1E8] text-sm font-medium"
              >
                <Phone className="w-4 h-4 text-[#C5A059]" /> {phoneDisplay}
              </a>
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onScrollToContact();
                }}
                className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#C5A059] to-[#A88238] text-[#0A0A0C] font-semibold text-xs uppercase tracking-[0.18em]"
              >
                Solicitar Asesoramiento
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
