import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowDownRight, MapPin, Sparkles } from 'lucide-react';

interface HeroMosaicProps {
  slogan: string;
  directorName: string;
  location: string;
  onExploreCatalog: () => void;
  onSellProperty: () => void;
}

const MOSAIC_SIDE_TILES = [
  { src: '/images/penthouse-turia.jpg', label: 'El Pla del Real' },
  { src: '/images/palacete-xerea.jpg', label: 'Ciutat Vella' },
  { src: '/images/villa-monasterios.jpg', label: 'Los Monasterios' },
  { src: '/images/interior-salon.jpg', label: 'Interiorismo Noble' },
  // Center index (4) is the hero main frame
  { src: '/images/atico-patacona.jpg', label: 'Frente al Mediterráneo' },
  { src: '/images/obra-nueva-cortes.jpg', label: 'Cortes Valencianas' },
  { src: '/images/interior-cocina.jpg', label: 'Arquitectura a Medida' },
  { src: '/images/villa-campolivar.jpg', label: 'Campolivar' },
];

export default function HeroMosaic({
  slogan,
  directorName,
  location,
  onExploreCatalog,
  onSellProperty,
}: HeroMosaicProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  });

  // Reproduces the exact zoom-out into 3x3 mosaic transition seen in reference video frames 00 -> 03
  const centerScale = useTransform(scrollYProgress, [0, 0.85], [1, 0.34]);
  const centerRadius = useTransform(scrollYProgress, [0, 0.6], [0, 28]);
  const overlayContentOpacity = useTransform(scrollYProgress, [0, 0.42], [1, 0]);
  const overlayContentY = useTransform(scrollYProgress, [0, 0.42], [0, -28]);
  const outerGridOpacity = useTransform(scrollYProgress, [0.12, 0.72], [0, 1]);
  const outerGridScale = useTransform(scrollYProgress, [0.08, 0.85], [1.22, 1]);

  return (
    <section
      id="inicio"
      ref={containerRef}
      className="relative h-[155vh] md:h-[185vh] bg-[#0A0A0C]"
      aria-label="Portada EYN LUXE Exclusive Real Estate"
    >
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center bg-[#0A0A0C]">
        {/* Surrounding 3x3 Architectural Mosaic revealed during scroll zoom-out */}
        <motion.div
          style={{ opacity: outerGridOpacity, scale: outerGridScale }}
          className="absolute inset-0 p-3 sm:p-6 md:p-8 grid grid-cols-3 grid-rows-3 gap-3 sm:gap-4 md:gap-5 pointer-events-none max-w-[1600px] mx-auto"
          aria-hidden="true"
        >
          {/* Top row */}
          {[MOSAIC_SIDE_TILES[0], MOSAIC_SIDE_TILES[1], MOSAIC_SIDE_TILES[2]].map((tile, i) => (
            <div
              key={i}
              className="relative rounded-2xl md:rounded-3xl overflow-hidden border border-[#C5A059]/20 bg-[#141418]"
            >
              <img
                src={tile.src}
                alt={tile.label}
                className="w-full h-full object-cover brightness-85"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C]/80 via-transparent to-transparent" />
              <span className="hidden sm:block absolute bottom-3 left-4 text-[11px] uppercase tracking-[0.18em] text-[#F5F1E8]/85">
                {tile.label}
              </span>
            </div>
          ))}

          {/* Middle row: left tile, empty center slot for scaled hero, right tile */}
          <div className="relative rounded-2xl md:rounded-3xl overflow-hidden border border-[#C5A059]/20 bg-[#141418]">
            <img
              src={MOSAIC_SIDE_TILES[3].src}
              alt={MOSAIC_SIDE_TILES[3].label}
              className="w-full h-full object-cover brightness-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C]/80 via-transparent to-transparent" />
            <span className="hidden sm:block absolute bottom-3 left-4 text-[11px] uppercase tracking-[0.18em] text-[#F5F1E8]/85">
              {MOSAIC_SIDE_TILES[3].label}
            </span>
          </div>

          <div className="rounded-2xl md:rounded-3xl" />

          <div className="relative rounded-2xl md:rounded-3xl overflow-hidden border border-[#C5A059]/20 bg-[#141418]">
            <img
              src={MOSAIC_SIDE_TILES[4].src}
              alt={MOSAIC_SIDE_TILES[4].label}
              className="w-full h-full object-cover brightness-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C]/80 via-transparent to-transparent" />
            <span className="hidden sm:block absolute bottom-3 left-4 text-[11px] uppercase tracking-[0.18em] text-[#F5F1E8]/85">
              {MOSAIC_SIDE_TILES[4].label}
            </span>
          </div>

          {/* Bottom row */}
          {[MOSAIC_SIDE_TILES[5], MOSAIC_SIDE_TILES[6], MOSAIC_SIDE_TILES[7]].map((tile, i) => (
            <div
              key={i}
              className="relative rounded-2xl md:rounded-3xl overflow-hidden border border-[#C5A059]/20 bg-[#141418]"
            >
              <img
                src={tile.src}
                alt={tile.label}
                className="w-full h-full object-cover brightness-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C]/80 via-transparent to-transparent" />
              <span className="hidden sm:block absolute bottom-3 left-4 text-[11px] uppercase tracking-[0.18em] text-[#F5F1E8]/85">
                {tile.label}
              </span>
            </div>
          ))}
        </motion.div>

        {/* Main Centerpiece Architectural Frame */}
        <motion.div
          style={{
            scale: centerScale,
            borderRadius: centerRadius,
          }}
          className="relative z-10 w-full h-full overflow-hidden shadow-[0_0_90px_rgba(0,0,0,0.85)] border border-[#C5A059]/25"
        >
          <img
            src="/images/hero-villa.jpg"
            alt="Residencia exclusiva EYN LUXE en Valencia"
            className="w-full h-full object-cover object-center scale-[1.03]"
            loading="eager"
          />
          {/* Rich obsidian & warm bronze editorial gradient overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C] via-[#0A0A0C]/45 to-[#0A0A0C]/55" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0C]/80 via-transparent to-[#0A0A0C]/65" />
        </motion.div>

        {/* Editorial Foreground Typography matching Reference Composition */}
        <motion.div
          style={{ opacity: overlayContentOpacity, y: overlayContentY }}
          className="absolute inset-0 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-10 sm:pb-14 flex flex-col justify-between pointer-events-none"
        >
          {/* Top-right floating tag (matches reference top-right micro-headline) */}
          <div className="flex justify-between items-start gap-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0A0A0C]/70 backdrop-blur-md border border-[#C5A059]/35">
              <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
              <span className="text-[11px] uppercase tracking-[0.2em] text-[#F5F1E8]/90">
                Boutique Inmobiliaria · {location}
              </span>
            </div>

            <div className="hidden sm:flex flex-col items-end text-right">
              <span className="text-xs uppercase tracking-[0.22em] text-[#DFC286] font-medium">
                Comercialización Exclusiva
              </span>
              <span className="text-xs text-[#F5F1E8]/70 mt-0.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#C5A059]" /> Sede Comercial en {location}
              </span>
            </div>
          </div>

          {/* Bottom asymmetric split: Monumental Serif Left + Signature & Actions Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end pointer-events-auto">
            <div className="lg:col-span-8">
              <motion.p
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-xs sm:text-sm uppercase tracking-[0.26em] text-[#C5A059] mb-3 font-medium"
              >
                EYN LUXE — Exclusive Real Estate
              </motion.p>
              <motion.h1
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.75, delay: 0.1 }}
                className="font-serif-luxe text-4xl sm:text-6xl md:text-7xl lg:text-[5.15rem] leading-[1.02] text-white font-normal tracking-tight"
              >
                {slogan.includes('exclusivas') ? (
                  <>
                    Propiedades <span className="italic text-[#DFC286]">exclusivas</span> para personas excepcionales.
                  </>
                ) : (
                  slogan
                )}
              </motion.h1>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.22 }}
              className="lg:col-span-4 flex flex-col lg:items-end lg:text-right justify-end space-y-5"
            >
              <div className="border-l-2 lg:border-l-0 lg:border-r-2 border-[#C5A059] pl-4 lg:pl-0 lg:pr-4">
                <p className="font-serif-luxe text-2xl sm:text-3xl text-white leading-tight">
                  {directorName}
                </p>
                <p className="text-xs uppercase tracking-[0.2em] text-[#F5F1E8]/75 mt-1">
                  Dirección &amp; Asesoramiento Privado
                </p>
              </div>

              <div className="flex flex-wrap lg:justify-end gap-3 pt-1">
                <button
                  type="button"
                  onClick={onExploreCatalog}
                  className="px-6 py-3.5 rounded-full bg-gradient-to-r from-[#C5A059] via-[#D6B673] to-[#AD863B] text-[#0A0A0C] text-xs font-semibold uppercase tracking-[0.16em] hover:brightness-110 transition-all flex items-center gap-2 shadow-[0_8px_30px_rgba(197,160,89,0.3)] cursor-pointer"
                >
                  Explorar Propiedades <ArrowDownRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onSellProperty}
                  className="px-5 py-3.5 rounded-full bg-[#0A0A0C]/75 backdrop-blur-md border border-[#F5F1E8]/25 hover:border-[#C5A059] text-[#F5F1E8] text-xs font-medium uppercase tracking-[0.15em] transition-all cursor-pointer"
                >
                  Vender con EYN LUXE
                </button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
