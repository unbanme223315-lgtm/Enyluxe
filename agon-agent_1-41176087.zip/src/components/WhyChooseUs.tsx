import { motion } from 'framer-motion';
import { Crown, ShieldCheck, Compass } from 'lucide-react';

interface WhyChooseUsProps {
  keyMessage: string;
}

const PILLARS = [
  {
    icon: Crown,
    title: 'Posicionamiento que Destaca',
    description:
      'Presentación editorial de cada inmueble con fotografía arquitectónica, narrativa cuidada y alcance cualificado para defender el verdadero valor de su patrimonio.',
    progressWidth: '68%',
  },
  {
    icon: ShieldCheck,
    title: 'Rigor, Discreción y Confianza',
    description:
      'Interlocución única y directa con Estefanía Yáñez, filtrado riguroso de solvencia y supervisión documental y jurídica completa hasta la firma ante notario.',
    progressWidth: '82%',
  },
  {
    icon: Compass,
    title: 'Visión Integral y Construcción',
    description:
      'Acompañamiento experto desde la adquisición, venta o alquiler selecto hasta proyectos de obra nueva, arquitectura y reforma integral en Valencia.',
    progressWidth: '76%',
  },
];

export default function WhyChooseUs({ keyMessage }: WhyChooseUsProps) {
  return (
    <section
      id="por-que"
      className="py-24 md:py-32 bg-[#0A0A0C]"
      aria-labelledby="porque-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Centered Header reproducing Reference Video Frame 10-11 */}
        <div className="text-center max-w-3xl mx-auto mb-16 md:mb-24">
          <motion.h2
            id="porque-heading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6 }}
            className="font-serif-luxe text-4xl sm:text-5xl md:text-6xl text-white font-normal tracking-tight"
          >
            ¿Por qué confiar en <span className="italic text-[#DFC286]">EYN LUXE</span>?
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: 0.12 }}
            className="mt-4 text-base sm:text-lg text-[#F5F1E8]/75 font-light"
          >
            {keyMessage}
          </motion.p>
        </div>

        {/* 3 Clean Columns with Thin Gold Icons & Animated Bottom Progress Hairlines */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 lg:gap-14">
          {PILLARS.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.25 }}
                transition={{ duration: 0.6, delay: idx * 0.12 }}
                className="group flex flex-col justify-between"
              >
                <div>
                  <div className="mb-7 inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-[#141419] border border-[#C5A059]/30 text-[#C5A059] group-hover:border-[#DFC286] group-hover:scale-105 transition-all">
                    <Icon className="w-6 h-6 stroke-[1.5]" />
                  </div>
                  <h3 className="font-serif-luxe text-2xl sm:text-3xl text-white mb-3.5">
                    {pillar.title}
                  </h3>
                  <p className="text-sm sm:text-base text-[#F5F1E8]/68 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                {/* Animated Gold Accent Line matching Reference Video Frame 11 */}
                <div className="mt-9 w-full h-[2px] bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: '0%' }}
                    whileInView={{ width: pillar.progressWidth }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.1, delay: 0.25 + idx * 0.15, ease: 'easeOut' }}
                    className="h-full bg-gradient-to-r from-[#C5A059] to-[#DFC286] group-hover:!w-full transition-all duration-500"
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
