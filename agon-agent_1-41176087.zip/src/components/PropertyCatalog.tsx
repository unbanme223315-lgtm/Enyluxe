import { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Heart, BedDouble, Bath, Maximize2, MapPin, ArrowUpRight, RotateCcw } from 'lucide-react';
import type { Property } from '../types/eyn';

interface PropertyCatalogProps {
  properties: Property[];
  loading: boolean;
  favorites: number[];
  onToggleFavorite: (id: number) => void;
  onSelectProperty: (property: Property) => void;
  externalZoneFilter: string;
  onClearExternalZone: () => void;
}

const OPERATIONS = ['Todas', 'Venta', 'Alquiler', 'Construcción', 'Comercialización Exclusiva'];

export default function PropertyCatalog({
  properties,
  loading,
  favorites,
  onToggleFavorite,
  onSelectProperty,
  externalZoneFilter,
  onClearExternalZone,
}: PropertyCatalogProps) {
  const [operation, setOperation] = useState('Todas');
  const [search, setSearch] = useState('');
  const [maxPrice, setMaxPrice] = useState<number>(0);
  const [minBeds, setMinBeds] = useState<number>(0);

  const filtered = useMemo(() => {
    return properties.filter((p) => {
      if (operation !== 'Todas' && p.operation !== operation) return false;
      if (externalZoneFilter && !p.zone.toLowerCase().includes(externalZoneFilter.toLowerCase())) {
        return false;
      }
      if (maxPrice > 0 && p.price > maxPrice) return false;
      if (minBeds > 0 && p.bedrooms < minBeds) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const match =
          p.title.toLowerCase().includes(q) ||
          p.zone.toLowerCase().includes(q) ||
          p.reference.toLowerCase().includes(q) ||
          p.property_type.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [properties, operation, externalZoneFilter, maxPrice, minBeds, search]);

  const resetFilters = () => {
    setOperation('Todas');
    setSearch('');
    setMaxPrice(0);
    setMinBeds(0);
    onClearExternalZone();
  };

  const formatPrice = (prop: Property) => {
    if (prop.price_label) return prop.price_label;
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(prop.price);
  };

  return (
    <section
      id="catalogo"
      className="py-20 md:py-28 bg-[#0D0D11] border-y border-white/[0.06]"
      aria-labelledby="catalogo-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-2">
              Catálogo Residencial &amp; Patrimonial
            </p>
            <h2
              id="catalogo-heading"
              className="font-serif-luxe text-3xl sm:text-5xl text-white font-normal"
            >
              Propiedades Disponibles en Valencia
            </h2>
          </div>
          <p className="text-sm text-[#F5F1E8]/65 max-w-md">
            Cada activo ha sido verificado técnica y documentalmente bajo criterios de calidad arquitectónica, ubicación y potencial patrimonial.
          </p>
        </div>

        {/* Filter Console */}
        <div className="rounded-3xl bg-[#141419] border border-[#C5A059]/20 p-4 sm:p-6 mb-12 shadow-xl">
          {/* Operation Pills */}
          <div className="flex flex-wrap items-center gap-2 pb-5 border-b border-white/8">
            {OPERATIONS.map((op) => (
              <button
                key={op}
                type="button"
                onClick={() => setOperation(op)}
                className={`px-4 py-2 rounded-full text-xs uppercase tracking-[0.14em] transition-all cursor-pointer ${
                  operation === op
                    ? 'bg-[#C5A059] text-[#0A0A0C] font-semibold shadow-[0_0_20px_rgba(197,160,89,0.3)]'
                    : 'bg-white/[0.04] text-[#F5F1E8]/75 hover:bg-white/[0.08] hover:text-white'
                }`}
              >
                {op}
              </button>
            ))}

            {externalZoneFilter && (
              <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C5A059]/20 border border-[#C5A059]/50 text-xs text-[#DFC286]">
                Zona: {externalZoneFilter}
                <button
                  type="button"
                  onClick={onClearExternalZone}
                  className="hover:text-white font-bold cursor-pointer"
                  aria-label="Quitar filtro de zona"
                >
                  ×
                </button>
              </span>
            )}
          </div>

          {/* Search & Dropdowns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 pt-5 items-center">
            <div className="lg:col-span-5 relative">
              <Search className="w-4 h-4 text-[#C5A059] absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por zona, tipología, terraza, referencia..."
                aria-label="Buscar propiedades"
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-[#F5F1E8] placeholder:text-[#F5F1E8]/40 focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div className="lg:col-span-3">
              <select
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                aria-label="Precio máximo"
                className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-[#F5F1E8] focus:outline-none focus:border-[#C5A059]"
              >
                <option value={0}>Presupuesto: Sin límite</option>
                <option value={6000}>Alquiler hasta 6.000 € / mes</option>
                <option value={950000}>Hasta 950.000 €</option>
                <option value={1800000}>Hasta 1.800.000 €</option>
                <option value={3500000}>Hasta 3.500.000 €</option>
              </select>
            </div>

            <div className="lg:col-span-2">
              <select
                value={minBeds}
                onChange={(e) => setMinBeds(Number(e.target.value))}
                aria-label="Dormitorios mínimos"
                className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-[#F5F1E8] focus:outline-none focus:border-[#C5A059]"
              >
                <option value={0}>Dormitorios: Todos</option>
                <option value={2}>2+ Dormitorios</option>
                <option value={3}>3+ Dormitorios</option>
                <option value={4}>4+ Dormitorios</option>
              </select>
            </div>

            <div className="lg:col-span-2 flex justify-end">
              <button
                type="button"
                onClick={resetFilters}
                className="w-full py-3 px-4 rounded-xl border border-white/15 hover:border-[#C5A059] text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/80 hover:text-[#DFC286] flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Limpiar
              </button>
            </div>
          </div>
        </div>

        {/* Loading Skeleton */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div
                key={n}
                className="h-[440px] rounded-3xl bg-[#141419] border border-white/8 animate-pulse"
              />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 px-6 rounded-3xl bg-[#141419] border border-white/10">
            <SlidersHorizontal className="w-10 h-10 text-[#C5A059] mx-auto mb-3" />
            <h3 className="font-serif-luxe text-2xl text-white">
              No hay propiedades que coincidan con los filtros seleccionados
            </h3>
            <p className="text-sm text-[#F5F1E8]/65 mt-2 max-w-md mx-auto">
              Disponemos además de activos confidenciales (off-market) en Valencia gestionados personalmente por Estefanía Yáñez.
            </p>
            <button
              type="button"
              onClick={resetFilters}
              className="mt-6 px-6 py-3 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-semibold uppercase tracking-[0.16em] cursor-pointer"
            >
              Ver toda la cartera disponible
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filtered.map((prop) => {
              const isFav = favorites.includes(prop.id);
              return (
                <article
                  key={prop.id}
                  className="group rounded-[24px] bg-[#141419] border border-white/10 hover:border-[#C5A059]/55 overflow-hidden flex flex-col justify-between transition-all duration-500 hover:-translate-y-1 shadow-[0_14px_40px_rgba(0,0,0,0.45)]"
                >
                  <div>
                    {/* Image Header */}
                    <div
                      onClick={() => onSelectProperty(prop)}
                      className="relative h-64 overflow-hidden cursor-pointer"
                    >
                      <img
                        src={prop.main_image}
                        alt={prop.title}
                        className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-700"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#141419] via-transparent to-[#0A0A0C]/40" />

                      <div className="absolute top-3.5 left-3.5 flex flex-wrap gap-1.5">
                        <span className="px-3 py-1 rounded-full bg-[#0A0A0C]/85 backdrop-blur-md border border-[#C5A059]/45 text-[10px] uppercase tracking-[0.15em] text-[#DFC286] font-medium">
                          {prop.operation}
                        </span>
                        {prop.status === 'Reservado' && (
                          <span className="px-3 py-1 rounded-full bg-amber-500/90 text-[#0A0A0C] text-[10px] uppercase tracking-[0.15em] font-bold">
                            Reservado
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(prop.id);
                        }}
                        aria-label={isFav ? 'Quitar de favoritos' : 'Guardar en favoritos'}
                        className={`absolute top-3.5 right-3.5 w-9 h-9 rounded-full backdrop-blur-md flex items-center justify-center border transition-all cursor-pointer ${
                          isFav
                            ? 'bg-[#C5A059] border-[#C5A059] text-[#0A0A0C]'
                            : 'bg-[#0A0A0C]/70 border-white/20 text-white hover:border-[#C5A059]'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                      </button>

                      <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
                        <span className="text-[11px] uppercase tracking-[0.16em] text-[#F5F1E8]/80">
                          Ref. {prop.reference}
                        </span>
                        <span className="font-serif-luxe text-2xl font-semibold text-[#DFC286]">
                          {formatPrice(prop)}
                        </span>
                      </div>
                    </div>

                    {/* Body */}
                    <div className="p-6">
                      <p className="text-xs text-[#C5A059] flex items-center gap-1.5 mb-1.5">
                        <MapPin className="w-3.5 h-3.5 shrink-0" /> {prop.zone}
                      </p>
                      <h3
                        onClick={() => onSelectProperty(prop)}
                        className="font-serif-luxe text-2xl text-white group-hover:text-[#DFC286] transition-colors cursor-pointer line-clamp-1"
                      >
                        {prop.title}
                      </h3>
                      <p className="mt-2 text-sm text-[#F5F1E8]/65 line-clamp-2 leading-relaxed">
                        {prop.subtitle || prop.description}
                      </p>
                    </div>
                  </div>

                  {/* Specs & Action Footer */}
                  <div className="px-6 pb-6 pt-3 border-t border-white/8 flex items-center justify-between text-xs text-[#F5F1E8]/75">
                    <div className="flex items-center gap-3.5">
                      <span className="flex items-center gap-1">
                        <Maximize2 className="w-3.5 h-3.5 text-[#C5A059]" /> {prop.area_m2} m²
                      </span>
                      {prop.bedrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <BedDouble className="w-3.5 h-3.5 text-[#C5A059]" /> {prop.bedrooms}
                        </span>
                      )}
                      {prop.bathrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <Bath className="w-3.5 h-3.5 text-[#C5A059]" /> {prop.bathrooms}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectProperty(prop)}
                      className="inline-flex items-center gap-1 uppercase tracking-[0.15em] text-[#DFC286] font-semibold group-hover:translate-x-0.5 transition-transform cursor-pointer"
                    >
                      Detalle <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
