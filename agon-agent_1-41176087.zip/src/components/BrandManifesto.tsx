import { motion } from 'framer-motion';

interface BrandManifestoProps {
  keyMessage: string;
  directorName: string;
}

const FLOATING_SEALS = [
  { label: 'Valencia · España', pos: 'top-8 left-[8%] md:left-[14%]', blur: false },
  { label: 'Confidencialidad', pos: 'top-14 right-[8%] md:right-[15%]', blur: true },
  { label: 'Cartera Selecta', pos: 'bottom-14 left-[10%] md:left-[18%]', blur: true },
  { label: 'Arquitectura & Valor', pos: 'bottom-10 right-[10%] md:right-[16%]', blur: false },
];

export default function BrandManifesto({ keyMessage, directorName }: BrandManifestoProps) {
  return (
    <section
      className="relative py-28 sm:py-36 md:py-44 bg-[#0A0A0C] overflow-hidden"
      aria-label="Manifiesto EYN LUXE"
    >
      {/* Subtle Ambient Gold Radial Glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 50%, rgba(197,160,89,0.11) 0%, rgba(10,10,12,0) 62%)',
        }}
      />

      {/* Ambient Floating Brand Attribute Pills matching Reference Video Frames 18-19 */}
      {FLOATING_SEALS.map((seal, i) => (
        <motion.div
          key={seal.label}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: seal.blur ? 0.42 : 0.78, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: i * 0.15 }}
          className={`hidden sm:inline-flex absolute ${seal.pos} px-4 py-2 rounded-full bg-[#15151B]/90 border border-[#C5A059]/25 text-[11px] uppercase tracking-[0.2em] text-[#DFC286] pointer-events-none ${
            seal.blur ? 'blur-[0.6px] scale-95' : 'shadow-[0_0_24px_rgba(197,160,89,0.12)]'
          }`}
        >
          {seal.label}
        </motion.div>
      ))}

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <p className="text-xs uppercase tracking-[0.28em] text-[#C5A059] mb-5">
          Filosofía EYN LUXE
        </p>
        <motion.blockquote
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.75 }}
          className="font-serif-luxe text-3xl sm:text-5xl md:text-6xl text-white leading-[1.14] font-normal"
        >
          «{keyMessage}»
        </motion.blockquote>
        <p className="mt-7 text-xs sm:text-sm uppercase tracking-[0.22em] text-[#F5F1E8]/65">
          — {directorName} · Exclusive Real Estate Valencia
        </p>
      </div>
    </section>
  );
}
