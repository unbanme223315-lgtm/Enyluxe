import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import type { FaqItem } from '../types/eyn';

interface FaqSectionProps {
  faqs: FaqItem[];
}

export default function FaqSection({ faqs }: FaqSectionProps) {
  const [openId, setOpenId] = useState<number | null>(faqs[0]?.id ?? null);

  if (!faqs || faqs.length === 0) return null;

  return (
    <section
      id="faq"
      className="py-24 md:py-32 bg-[#0A0A0C] border-t border-white/[0.06]"
      aria-labelledby="faq-heading"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Centered Serif Heading matching Reference Video Frame 22 */}
        <div className="text-center mb-14 md:mb-18">
          <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-3">
            Resolución de Dudas
          </p>
          <h2
            id="faq-heading"
            className="font-serif-luxe text-4xl sm:text-5xl md:text-6xl text-white font-normal"
          >
            Preguntas Frecuentes
          </h2>
        </div>

        {/* Expandable Rows with Circular + / Gold - Buttons matching Reference Frame 22-23 */}
        <div className="divide-y divide-white/12 border-y border-white/12">
          {faqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div key={faq.id} className="py-6 sm:py-7">
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between gap-6 text-left group cursor-pointer"
                >
                  <span className="font-serif-luxe text-xl sm:text-2xl text-white group-hover:text-[#DFC286] transition-colors leading-snug">
                    {faq.question}
                  </span>
                  <span
                    className={`w-9 h-9 rounded-full shrink-0 flex items-center justify-center transition-all duration-300 ${
                      isOpen
                        ? 'bg-[#C5A059] text-[#0A0A0C] shadow-[0_0_20px_rgba(197,160,89,0.45)]'
                        : 'border border-white/20 text-[#F5F1E8] group-hover:border-[#C5A059]'
                    }`}
                  >
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </span>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <p className="pt-4 pr-10 text-sm sm:text-base text-[#F5F1E8]/72 leading-relaxed">
                        {faq.answer}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
