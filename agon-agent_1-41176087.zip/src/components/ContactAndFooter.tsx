import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Phone,
  MessageCircle,
  MapPin,
  CheckCircle2,
  Send,
  ArrowUpRight,
  X,
  Lock,
  Mail,
} from 'lucide-react';
import type { SiteSettings } from '../types/eyn';

interface ContactAndFooterProps {
  settings: SiteSettings;
  preselectedService: string;
}

const SERVICE_OPTIONS = [
  'Comercialización Exclusiva',
  'Compra de Propiedad',
  'Venta de Propiedad',
  'Alquiler Residencial',
  'Construcción y Reforma',
  'Asesoramiento Personalizado',
];

export default function ContactAndFooter({
  settings,
  preselectedService,
}: ContactAndFooterProps) {
  const directorName = settings.director_name || 'Estefanía Yáñez';
  const location = settings.location || 'Valencia, España';
  const phoneDisplay = settings.phone_display || '+34 658 659 387';
  const phoneClean = settings.phone_clean || '34658659387';
  const corporateEmail = settings.corporate_email || '';
  const postalAddress = settings.postal_address || 'Valencia, España (Atención con cita previa)';
  const legalIdNote =
    settings.legal_id_note ||
    'Datos identificativos fiscales y registrales gestionables por la titular en el Panel de Administración.';

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [serviceType, setServiceType] = useState(
    preselectedService || 'Comercialización Exclusiva'
  );
  const [preferredContact, setPreferredContact] = useState('Teléfono / WhatsApp');
  const [budgetOrValuation, setBudgetOrValuation] = useState('');
  const [message, setMessage] = useState('');
  const [gdpr, setGdpr] = useState(false);
  const [websiteHp, setWebsiteHp] = useState(''); // anti-spam honeypot
  const [submitting, setSubmitting] = useState(false);
  const [sentOk, setSentOk] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [legalModal, setLegalModal] = useState<'aviso' | 'privacidad' | 'cookies' | null>(null);

  useEffect(() => {
    if (preselectedService) {
      setServiceType(preselectedService);
    }
  }, [preselectedService]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitting(true);

    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: fullName,
          phone,
          email,
          service_type: serviceType,
          preferred_contact: preferredContact,
          budget_or_valuation: budgetOrValuation,
          message,
          gdpr_accepted: gdpr,
          website_hp: websiteHp,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'No se pudo registrar la consulta.');

      setSentOk(true);
      setFullName('');
      setPhone('');
      setEmail('');
      setBudgetOrValuation('');
      setMessage('');
      setGdpr(false);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Error al enviar el formulario.');
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappDirectUrl = `https://wa.me/${phoneClean}?text=${encodeURIComponent(
    `Hola ${directorName}, deseo solicitar asesoramiento inmobiliario con EYN LUXE en Valencia.`
  )}`;

  return (
    <>
      {/* Private Consultation & Property Valuation Section */}
      <section
        id="contacto"
        className="py-24 md:py-32 bg-[#0A0A0C] border-t border-white/[0.06]"
        aria-labelledby="contacto-heading"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left Editorial Contact Details */}
            <div className="lg:col-span-5 space-y-8">
              <div>
                <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-3">
                  Contacto Directo &amp; Captación
                </p>
                <h2
                  id="contacto-heading"
                  className="font-serif-luxe text-4xl sm:text-5xl text-white font-normal leading-tight"
                >
                  Hablemos con Discreción <span className="italic text-[#DFC286]">y Claridad</span>
                </h2>
                <p className="mt-4 text-sm sm:text-base text-[#F5F1E8]/72 leading-relaxed">
                  Tanto si desea confiar la comercialización exclusiva de su propiedad en Valencia como si busca una residencia o inversión singular, recibirá atención directa y personalizada de{' '}
                  <strong className="text-white font-medium">{directorName}</strong>.
                </p>
              </div>

              <div className="rounded-3xl bg-[#131318] border border-[#C5A059]/25 p-6 sm:p-8 space-y-5">
                <div>
                  <span className="text-[11px] uppercase tracking-[0.2em] text-[#C5A059] block">
                    Responsable Comercial
                  </span>
                  <span className="font-serif-luxe text-2xl text-white mt-0.5 block">
                    {directorName}
                  </span>
                </div>

                <div className="pt-4 border-t border-white/10 space-y-3.5 text-sm">
                  <a
                    href={`tel:+${phoneClean}`}
                    className="flex items-center gap-3 text-[#F5F1E8] hover:text-[#DFC286] transition-colors"
                  >
                    <span className="w-10 h-10 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/35 flex items-center justify-center text-[#DFC286]">
                      <Phone className="w-4 h-4" />
                    </span>
                    <span>
                      <span className="block text-xs text-[#F5F1E8]/55">Atención Telefónica</span>
                      <strong className="font-medium tracking-wide">{phoneDisplay}</strong>
                    </span>
                  </a>

                  <a
                    href={whatsappDirectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[#F5F1E8] hover:text-emerald-300 transition-colors"
                  >
                    <span className="w-10 h-10 rounded-full bg-emerald-500/15 border border-emerald-500/35 flex items-center justify-center text-emerald-300">
                      <MessageCircle className="w-4 h-4" />
                    </span>
                    <span>
                      <span className="block text-xs text-[#F5F1E8]/55">WhatsApp Privado</span>
                      <strong className="font-medium tracking-wide">{phoneDisplay}</strong>
                    </span>
                  </a>

                  {corporateEmail && (
                    <a
                      href={`mailto:${corporateEmail}`}
                      className="flex items-center gap-3 text-[#F5F1E8] hover:text-[#DFC286] transition-colors"
                    >
                      <span className="w-10 h-10 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/35 flex items-center justify-center text-[#DFC286]">
                        <Mail className="w-4 h-4" />
                      </span>
                      <span>
                        <span className="block text-xs text-[#F5F1E8]/55">Correo Corporativo</span>
                        <strong className="font-medium">{corporateEmail}</strong>
                      </span>
                    </a>
                  )}

                  <div className="flex items-center gap-3 text-[#F5F1E8]">
                    <span className="w-10 h-10 rounded-full bg-white/[0.05] border border-white/12 flex items-center justify-center text-[#C5A059]">
                      <MapPin className="w-4 h-4" />
                    </span>
                    <span>
                      <span className="block text-xs text-[#F5F1E8]/55">Sede Comercial</span>
                      <strong className="font-medium">{location}</strong>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Validated Consultation Form */}
            <div className="lg:col-span-7">
              <div className="rounded-[28px] bg-[#131318] border border-white/10 p-6 sm:p-10 shadow-2xl">
                <h3 className="font-serif-luxe text-2xl sm:text-3xl text-white mb-2">
                  Solicitud de Asesoramiento o Valoración
                </h3>
                <p className="text-xs sm:text-sm text-[#F5F1E8]/60 mb-7">
                  Complete sus datos y nos pondremos en contacto con usted con absoluta confidencialidad.
                </p>

                {sentOk ? (
                  <div className="p-7 rounded-2xl bg-[#C5A059]/12 border border-[#C5A059]/45 text-center space-y-3">
                    <CheckCircle2 className="w-10 h-10 text-[#DFC286] mx-auto" />
                    <h4 className="font-serif-luxe text-2xl text-white">
                      Gracias por contactar con EYN LUXE
                    </h4>
                    <p className="text-sm text-[#F5F1E8]/80 max-w-md mx-auto leading-relaxed">
                      Hemos registrado su solicitud correctamente. {directorName} se pondrá en contacto con usted a través de su canal preferente.
                    </p>
                    <button
                      type="button"
                      onClick={() => setSentOk(false)}
                      className="mt-3 px-6 py-2.5 rounded-full border border-[#C5A059]/50 text-xs uppercase tracking-[0.16em] text-[#DFC286] hover:bg-[#C5A059]/15 cursor-pointer"
                    >
                      Enviar otra consulta
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                    {/* Honeypot field hidden from screen readers and visual users */}
                    <input
                      type="text"
                      name="website_hp"
                      value={websiteHp}
                      onChange={(e) => setWebsiteHp(e.target.value)}
                      tabIndex={-1}
                      autoComplete="off"
                      className="hidden"
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Nombre completo *
                        </label>
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Su nombre y apellidos"
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Teléfono de contacto *
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+34 600 000 000"
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Correo electrónico *
                        </label>
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="nombre@dominio.es"
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Servicio requerido *
                        </label>
                        <select
                          value={serviceType}
                          onChange={(e) => setServiceType(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        >
                          {SERVICE_OPTIONS.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Canal preferente
                        </label>
                        <select
                          value={preferredContact}
                          onChange={(e) => setPreferredContact(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        >
                          <option value="Teléfono / WhatsApp">Teléfono / WhatsApp</option>
                          <option value="Llamada telefónica">Llamada telefónica</option>
                          <option value="WhatsApp">WhatsApp</option>
                          <option value="Correo electrónico">Correo electrónico</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                          Zona o presupuesto orientativo
                        </label>
                        <input
                          type="text"
                          value={budgetOrValuation}
                          onChange={(e) => setBudgetOrValuation(e.target.value)}
                          placeholder="Ej. El Pla del Real / 1,2M €"
                          className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                        Mensaje o características del inmueble *
                      </label>
                      <textarea
                        rows={4}
                        required
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Cuéntenos qué tipo de propiedad busca o describa brevemente el inmueble que desea comercializar en Valencia..."
                        className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                      />
                    </div>

                    <label className="flex items-start gap-2.5 text-xs text-[#F5F1E8]/70 cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        checked={gdpr}
                        onChange={(e) => setGdpr(e.target.checked)}
                        className="mt-0.5 accent-[#C5A059]"
                      />
                      <span>
                        He leído y acepto la{' '}
                        <button
                          type="button"
                          onClick={() => setLegalModal('privacidad')}
                          className="underline text-[#DFC286] hover:text-white cursor-pointer"
                        >
                          Política de Privacidad
                        </button>{' '}
                        para el tratamiento confidencial de mi solicitud por parte de EYN LUXE. *
                      </span>
                    </label>

                    {errorMsg && (
                      <p className="text-xs text-red-400 bg-red-950/40 border border-red-500/30 rounded-xl px-4 py-2.5">
                        {errorMsg}
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full sm:w-auto px-9 py-4 rounded-full bg-gradient-to-r from-[#C5A059] via-[#DFC286] to-[#A88238] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.18em] flex items-center justify-center gap-2 hover:brightness-110 transition-all disabled:opacity-50 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      {submitting ? 'Enviando solicitud...' : 'Enviar Solicitud Confidencial'}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reference Video Frame 23: Rounded Footer Container over Ambient Warm Gold Glow */}
      <footer className="relative pt-8 pb-12 px-4 sm:px-6 lg:px-8 bg-[#0A0A0C] overflow-hidden">
        {/* Ambient Burnished Gold Halo Underneath */}
        <div
          className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-[95%] max-w-6xl h-72 rounded-full blur-[90px] pointer-events-none"
          style={{
            background:
              'linear-gradient(90deg, rgba(142,109,47,0.38) 0%, rgba(223,194,134,0.45) 50%, rgba(142,109,47,0.38) 100%)',
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto rounded-[32px] bg-[#0E0E13]/94 backdrop-blur-xl border border-[#C5A059]/30 p-8 sm:p-12 lg:p-14 shadow-[0_20px_90px_rgba(0,0,0,0.85)]">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pb-12 border-b border-white/10">
            {/* Left Monumental Brand & CTA */}
            <div className="lg:col-span-7 space-y-5">
              <p className="font-serif-luxe text-3xl sm:text-5xl tracking-[0.2em] text-white/95 uppercase">
                EYN <span className="text-[#C5A059]">LUXE</span>
              </p>
              <h3 className="font-serif-luxe text-2xl sm:text-3xl text-[#F5F1E8]/90 font-normal max-w-xl">
                ¿Preparado para dar a su propiedad o inversión la proyección que merece?
              </h3>
              <div className="pt-2 flex flex-wrap gap-3">
                <a
                  href={`tel:+${phoneClean}`}
                  className="eyn-pill-btn h-11 px-7 rounded-full bg-gradient-to-r from-[#C5A059] via-[#DFC286] to-[#AC8539] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.16em] inline-flex items-center"
                >
                  <span className="eyn-pill-track h-22">
                    <span className="h-11 flex items-center gap-1.5">
                      Llamar Ahora <ArrowUpRight className="w-4 h-4" />
                    </span>
                    <span className="h-11 flex items-center gap-1.5">
                      {phoneDisplay} <ArrowUpRight className="w-4 h-4" />
                    </span>
                  </span>
                </a>
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-11 px-6 rounded-full border border-white/20 hover:border-[#C5A059] text-xs uppercase tracking-[0.15em] text-[#F5F1E8] inline-flex items-center gap-2 transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-[#C5A059]" /> WhatsApp Directo
                </a>
              </div>
            </div>

            {/* Right Contact & Navigation Columns */}
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-8 text-sm">
              <div className="space-y-2.5">
                <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059] mb-3">
                  Contacto Directo
                </p>
                <p className="text-white font-medium">{directorName}</p>
                <p className="text-[#F5F1E8]/70">{location}</p>
                <a
                  href={`tel:+${phoneClean}`}
                  className="block text-[#DFC286] hover:underline font-medium pt-1"
                >
                  {phoneDisplay}
                </a>
                {corporateEmail && (
                  <a
                    href={`mailto:${corporateEmail}`}
                    className="block text-[#F5F1E8]/75 hover:text-white break-all"
                  >
                    {corporateEmail}
                  </a>
                )}
              </div>

              <div className="space-y-2.5">
                <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059] mb-3">
                  Navegación &amp; Legal
                </p>
                <a href="#coleccion" className="block text-[#F5F1E8]/70 hover:text-[#DFC286]">
                  Colección Exclusiva
                </a>
                <a href="#catalogo" className="block text-[#F5F1E8]/70 hover:text-[#DFC286]">
                  Catálogo Valencia
                </a>
                <a href="#servicios" className="block text-[#F5F1E8]/70 hover:text-[#DFC286]">
                  Servicios Integrales
                </a>
                <button
                  type="button"
                  onClick={() => setLegalModal('aviso')}
                  className="block text-[#F5F1E8]/70 hover:text-[#DFC286] cursor-pointer"
                >
                  Aviso Legal
                </button>
                <button
                  type="button"
                  onClick={() => setLegalModal('privacidad')}
                  className="block text-[#F5F1E8]/70 hover:text-[#DFC286] cursor-pointer"
                >
                  Política de Privacidad
                </button>
                <button
                  type="button"
                  onClick={() => setLegalModal('cookies')}
                  className="block text-[#F5F1E8]/70 hover:text-[#DFC286] cursor-pointer"
                >
                  Política de Cookies
                </button>
              </div>
            </div>
          </div>

          <div className="pt-7 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#F5F1E8]/55">
            <p>
              © {new Date().getFullYear()} EYN LUXE – Exclusive Real Estate · {directorName} ·{' '}
              {location}. Todos los derechos reservados.
            </p>
            <Link
              to="/admin"
              className="inline-flex items-center gap-1.5 text-[#F5F1E8]/60 hover:text-[#DFC286] transition-colors"
            >
              <Lock className="w-3.5 h-3.5 text-[#C5A059]" /> Panel de Gestión
            </Link>
          </div>
        </div>
      </footer>

      {/* Floating Quick WhatsApp Action */}
      <a
        href={whatsappDirectUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contactar por WhatsApp con Estefanía Yáñez"
        className="fixed bottom-5 right-5 z-40 h-12 px-4 rounded-full bg-[#131318]/95 border border-[#C5A059]/55 text-[#F5F1E8] hover:border-[#DFC286] shadow-[0_10px_35px_rgba(0,0,0,0.75)] flex items-center gap-2.5 transition-transform hover:scale-105"
      >
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
        <MessageCircle className="w-4 h-4 text-[#C5A059]" />
        <span className="hidden sm:inline text-xs font-medium tracking-wide">
          Atención Directa
        </span>
      </a>

      {/* Legal Information Modal (Zero invented fiscal/NIF data) */}
      {legalModal && (
        <div
          onClick={() => setLegalModal(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-2xl w-full max-h-[85vh] overflow-y-auto rounded-3xl bg-[#131318] border border-[#C5A059]/35 p-7 sm:p-9 space-y-4 text-sm text-[#F5F1E8]/80"
          >
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="font-serif-luxe text-2xl text-white">
                {legalModal === 'aviso' && 'Aviso Legal'}
                {legalModal === 'privacidad' && 'Política de Privacidad (RGPD / LOPDGDD)'}
                {legalModal === 'cookies' && 'Política de Cookies'}
              </h3>
              <button
                type="button"
                onClick={() => setLegalModal(null)}
                className="w-8 h-8 rounded-full border border-white/15 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {legalModal === 'aviso' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  <strong>Denominación comercial:</strong> EYN LUXE – Exclusive Real Estate
                </p>
                <p>
                  <strong>Responsable comercial:</strong> {directorName}
                </p>
                <p>
                  <strong>Ubicación:</strong> {postalAddress}
                </p>
                <p>
                  <strong>Teléfono de contacto:</strong> {phoneDisplay}
                </p>
                {corporateEmail && (
                  <p>
                    <strong>Correo electrónico:</strong> {corporateEmail}
                  </p>
                )}
                <p className="text-xs text-[#C5A059] bg-[#C5A059]/10 p-3 rounded-xl border border-[#C5A059]/25">
                  Nota de configuración legal (LSSI-CE): {legalIdNote}
                </p>
                <p>
                  Toda la información e imágenes contenidas en este portal tienen carácter meramente informativo y no revisten carácter contractual, pudiendo estar sujetas a actualizaciones por encargo de la propiedad.
                </p>
              </div>
            )}

            {legalModal === 'privacidad' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  De conformidad con el Reglamento (UE) 2016/679 (RGPD) y la Ley Orgánica 3/2018 (LOPDGDD), le informamos de que los datos personales facilitados a través de los formularios de este sitio web serán tratados de forma confidencial por <strong>EYN LUXE – Exclusive Real Estate ({directorName})</strong>.
                </p>
                <p>
                  <strong>Finalidad:</strong> Atender su solicitud de información inmobiliaria, concertación de visitas privadas, valoración de inmuebles o prestación de servicios de intermediación y asesoramiento en {location}.
                </p>
                <p>
                  <strong>Legitimación:</strong> Consentimiento expreso de la persona interesada al marcar la casilla correspondiente antes del envío.
                </p>
                <p>
                  <strong>Destinatarios y conservación:</strong> Sus datos no se cederán a terceros salvo obligación legal y se conservarán únicamente durante el tiempo necesario para gestionar su consulta. Puede ejercer sus derechos de acceso, rectificación, supresión y oposición contactando en el teléfono {phoneDisplay}
                  {corporateEmail ? ` o en ${corporateEmail}` : ''}.
                </p>
              </div>
            )}

            {legalModal === 'cookies' && (
              <div className="space-y-3 leading-relaxed">
                <p>
                  Este sitio web utiliza exclusivamente almacenamiento técnico esencial (como la conservación local de su lista de inmuebles favoritos y la sesión segura de administración) necesario para el correcto funcionamiento de la plataforma, sin emplear cookies publicitarias invasivas de terceros.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
