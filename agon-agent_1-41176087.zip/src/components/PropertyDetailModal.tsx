import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  BedDouble,
  Bath,
  Maximize2,
  MapPin,
  CheckCircle2,
  Phone,
  MessageCircle,
  Sparkles,
  ShieldCheck,
  Send,
} from 'lucide-react';
import type { Property } from '../types/eyn';

interface PropertyDetailModalProps {
  property: Property | null;
  onClose: () => void;
  phoneDisplay: string;
  phoneClean: string;
  directorName: string;
}

export default function PropertyDetailModal({
  property,
  onClose,
  phoneDisplay,
  phoneClean,
  directorName,
}: PropertyDetailModalProps) {
  const [selectedImg, setSelectedImg] = useState(0);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [gdpr, setGdpr] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [sentOk, setSentOk] = useState(false);
  const [errMsg, setErrMsg] = useState('');

  if (!property) return null;

  const images = [
    property.main_image,
    ...(Array.isArray(property.gallery) ? property.gallery.filter((g) => g && g !== property.main_image) : []),
  ];
  const activeImg = images[selectedImg] || property.main_image;

  const formatPrice = (prop: Property) => {
    if (prop.price_label) return prop.price_label;
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(prop.price);
  };

  const whatsappText = encodeURIComponent(
    `Hola ${directorName}, me gustaría recibir información privada sobre la propiedad "${property.title}" (Ref. ${property.reference}) en EYN LUXE.`
  );

  const handleInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg('');
    setSubmitting(true);
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: fullName,
          phone,
          email,
          service_type: `Visita / Dossier (${property.operation})`,
          property_id: property.id,
          property_ref: property.reference,
          preferred_contact: 'Teléfono / WhatsApp',
          budget_or_valuation: formatPrice(property),
          message:
            message.trim() ||
            `Solicito información detallada y disponibilidad de visita privada para ${property.title} (Ref. ${property.reference}).`,
          gdpr_accepted: gdpr,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'No se pudo enviar la solicitud.');
      setSentOk(true);
      setFullName('');
      setPhone('');
      setEmail('');
      setMessage('');
    } catch (err: unknown) {
      setErrMsg(err instanceof Error ? err.message : 'Error al enviar.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-prop-title"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-6xl max-h-[92vh] overflow-y-auto rounded-[28px] bg-[#111116] border border-[#C5A059]/35 shadow-[0_30px_100px_rgba(0,0,0,0.9)]"
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar ficha de propiedad"
            className="sticky top-4 float-right mr-4 mt-4 z-20 w-10 h-10 rounded-full bg-[#0A0A0C]/90 border border-[#C5A059]/45 text-[#DFC286] flex items-center justify-center hover:bg-[#C5A059] hover:text-[#0A0A0C] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-5 sm:p-8 lg:p-10 clear-both">
            {/* Gallery + Summary Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-7 space-y-3">
                <div className="relative h-72 sm:h-[420px] rounded-2xl overflow-hidden border border-white/10 bg-[#0A0A0C]">
                  <img
                    src={activeImg}
                    alt={property.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                    <span className="px-3.5 py-1.5 rounded-full bg-[#0A0A0C]/85 border border-[#C5A059]/50 text-xs uppercase tracking-[0.16em] text-[#DFC286]">
                      {property.operation}
                    </span>
                    <span className="px-3.5 py-1.5 rounded-full bg-[#0A0A0C]/80 text-xs text-[#F5F1E8]">
                      Ref. {property.reference}
                    </span>
                  </div>
                </div>

                {images.length > 1 && (
                  <div className="flex gap-2.5 overflow-x-auto pb-1 no-scrollbar">
                    {images.map((imgUrl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedImg(idx)}
                        className={`relative w-24 h-16 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                          idx === selectedImg
                            ? 'border-[#C5A059] opacity-100'
                            : 'border-transparent opacity-55 hover:opacity-90'
                        }`}
                      >
                        <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}

                {/* Description & Highlights */}
                <div className="pt-4 space-y-5">
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059] mb-1">
                      Descripción Arquitectónica
                    </p>
                    <p className="text-sm sm:text-base text-[#F5F1E8]/85 leading-relaxed whitespace-pre-line">
                      {property.description}
                    </p>
                  </div>

                  {Array.isArray(property.highlights) && property.highlights.length > 0 && (
                    <div className="pt-2">
                      <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059] mb-3">
                        Atributos Destacados
                      </p>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {property.highlights.map((item, i) => (
                          <li
                            key={i}
                            className="flex items-start gap-2.5 text-sm text-[#F5F1E8]/80 bg-white/[0.03] rounded-xl p-3 border border-white/[0.06]"
                          >
                            <Sparkles className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: Price, Specs & Direct Request Form */}
              <div className="lg:col-span-5 space-y-6">
                <div className="rounded-2xl bg-[#16161D] border border-[#C5A059]/25 p-6">
                  <p className="text-xs uppercase tracking-[0.18em] text-[#C5A059] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" /> {property.zone}
                  </p>
                  <h2
                    id="modal-prop-title"
                    className="font-serif-luxe text-2xl sm:text-3xl text-white mt-1.5 leading-snug"
                  >
                    {property.title}
                  </h2>
                  <p className="font-serif-luxe text-3xl text-[#DFC286] font-semibold mt-3">
                    {formatPrice(property)}
                  </p>

                  {/* Specs Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-3 mt-5 pt-5 border-t border-white/10 text-xs">
                    <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                      <span className="text-[#F5F1E8]/55 block">Superficie</span>
                      <span className="text-white font-semibold text-sm flex items-center gap-1.5 mt-0.5">
                        <Maximize2 className="w-3.5 h-3.5 text-[#C5A059]" /> {property.area_m2} m²
                      </span>
                    </div>
                    {property.plot_m2 > 0 && (
                      <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                        <span className="text-[#F5F1E8]/55 block">Parcela</span>
                        <span className="text-white font-semibold text-sm mt-0.5 block">
                          {property.plot_m2} m²
                        </span>
                      </div>
                    )}
                    <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                      <span className="text-[#F5F1E8]/55 block">Dormitorios</span>
                      <span className="text-white font-semibold text-sm flex items-center gap-1.5 mt-0.5">
                        <BedDouble className="w-3.5 h-3.5 text-[#C5A059]" /> {property.bedrooms}
                      </span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                      <span className="text-[#F5F1E8]/55 block">Baños</span>
                      <span className="text-white font-semibold text-sm flex items-center gap-1.5 mt-0.5">
                        <Bath className="w-3.5 h-3.5 text-[#C5A059]" /> {property.bathrooms}
                      </span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                      <span className="text-[#F5F1E8]/55 block">Cert. Energético</span>
                      <span className="text-[#DFC286] font-semibold text-sm mt-0.5 block">
                        Clase {property.energy_rating || 'A'}
                      </span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#0A0A0C]/70 border border-white/8">
                      <span className="text-[#F5F1E8]/55 block">Tipología</span>
                      <span className="text-white font-semibold text-sm mt-0.5 block truncate">
                        {property.property_type}
                      </span>
                    </div>
                  </div>

                  {/* Direct Instant Contact */}
                  <div className="grid grid-cols-2 gap-2.5 mt-5">
                    <a
                      href={`tel:+${phoneClean}`}
                      className="py-3 px-3 rounded-xl border border-[#C5A059]/45 hover:bg-[#C5A059]/15 text-xs font-medium text-[#F5F1E8] flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#C5A059]" /> {phoneDisplay}
                    </a>
                    <a
                      href={`https://wa.me/${phoneClean}?text=${whatsappText}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-3 px-3 rounded-xl bg-emerald-600/20 border border-emerald-500/40 hover:bg-emerald-600/30 text-xs font-medium text-emerald-200 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Directo
                    </a>
                  </div>
                </div>

                {/* Private Visit / Dossier Form */}
                <div className="rounded-2xl bg-[#16161D] border border-white/10 p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                    <h3 className="font-serif-luxe text-xl text-white">
                      Solicitar Visita Privada o Dossier
                    </h3>
                  </div>

                  {sentOk ? (
                    <div className="p-4 rounded-xl bg-[#C5A059]/15 border border-[#C5A059]/45 text-sm text-[#F5F1E8] space-y-2">
                      <div className="flex items-center gap-2 text-[#DFC286] font-semibold">
                        <CheckCircle2 className="w-5 h-5" /> Solicitud registrada correctamente
                      </div>
                      <p className="text-xs text-[#F5F1E8]/80 leading-relaxed">
                        {directorName} atenderá personalmente su consulta sobre la referencia{' '}
                        <strong>{property.reference}</strong> a la mayor brevedad.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleInquiry} className="space-y-3">
                      <input
                        type="text"
                        required
                        placeholder="Nombre y apellidos *"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                      />
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="tel"
                          required
                          placeholder="Teléfono *"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                        <input
                          type="email"
                          required
                          placeholder="Correo electrónico *"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>
                      <textarea
                        rows={3}
                        placeholder={`Deseo recibir el dossier confidencial o concertar visita para Ref. ${property.reference}...`}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
                      />
                      <label className="flex items-start gap-2 text-xs text-[#F5F1E8]/70 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={gdpr}
                          onChange={(e) => setGdpr(e.target.checked)}
                          className="mt-0.5 accent-[#C5A059]"
                        />
                        <span>
                          Acepto el tratamiento confidencial de mis datos conforme a la Política de Privacidad de EYN LUXE.
                        </span>
                      </label>

                      {errMsg && (
                        <p className="text-xs text-red-400 bg-red-950/40 border border-red-500/30 rounded-lg px-3 py-2">
                          {errMsg}
                        </p>
                      )}

                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#C5A059] via-[#D8B978] to-[#AA8339] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.16em] flex items-center justify-center gap-2 hover:brightness-110 transition-all disabled:opacity-50 cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                        {submitting ? 'Enviando solicitud...' : 'Solicitar Atención Personalizada'}
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
