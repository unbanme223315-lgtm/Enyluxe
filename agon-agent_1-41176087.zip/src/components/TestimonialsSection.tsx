import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Testimonial } from '../types/eyn';

interface TestimonialsSectionProps {
  testimonials: Testimonial[];
}

export default function TestimonialsSection({ testimonials }: TestimonialsSectionProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  if (!testimonials || testimonials.length === 0) return null;

  const current = testimonials[activeIndex] || testimonials[0];

  const prev = () =>
    setActiveIndex((idx) => (idx - 1 + testimonials.length) % testimonials.length);
  const next = () =>
    setActiveIndex((idx) => (idx + 1) % testimonials.length);

  return (
    <section
      id="testimonios"
      className="py-24 md:py-32 bg-[#0A0A0C] border-t border-white/[0.06]"
      aria-labelledby="testimonios-heading"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-3">
            Relaciones Basadas en la Confianza
          </p>
          <h2
            id="testimonios-heading"
            className="font-serif-luxe text-4xl sm:text-5xl text-white font-normal"
          >
            La Experiencia de Nuestros Clientes
          </h2>
        </div>

        {/* Anthracite Card with Top Avatar Selector Ring matching Reference Video Frames 20-21 */}
        <div className="rounded-[30px] bg-[#121217] border border-[#C5A059]/22 p-7 sm:p-12 md:p-14 text-center shadow-[0_24px_70px_rgba(0,0,0,0.65)]">
          {/* Circular Avatar Strip */}
          <div className="flex items-center justify-center gap-3 sm:gap-4 mb-9 flex-wrap">
            {testimonials.map((item, idx) => {
              const isSelected = idx === activeIndex;
              const initials = item.client_name
                .split(' ')
                .slice(0, 2)
                .map((w) => w[0])
                .join('');
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveIndex(idx)}
                  aria-label={`Ver experiencia de ${item.client_name}`}
                  className={`relative rounded-full overflow-hidden transition-all duration-300 flex items-center justify-center cursor-pointer ${
                    isSelected
                      ? 'w-16 h-16 sm:w-20 sm:h-20 ring-2 ring-[#C5A059] ring-offset-4 ring-offset-[#121217] scale-105'
                      : 'w-11 h-11 sm:w-13 sm:h-13 opacity-45 hover:opacity-80 grayscale'
                  }`}
                >
                  {item.avatar_url ? (
                    <img
                      src={item.avatar_url}
                      alt={item.client_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="w-full h-full bg-[#1E1C18] text-[#DFC286] font-serif-luxe text-lg flex items-center justify-center">
                      {initials}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35 }}
              className="max-w-3xl mx-auto"
            >
              <h3 className="text-base sm:text-lg font-semibold text-[#DFC286]">
                {current.client_name}
              </h3>
              <p className="text-xs sm:text-sm text-[#F5F1E8]/60 mt-1">
                {current.client_role}
              </p>

              <blockquote className="mt-7 font-serif-luxe text-xl sm:text-2xl md:text-3xl text-[#F5F1E8]/92 leading-relaxed italic">
                “{current.quote}”
              </blockquote>
            </motion.div>
          </AnimatePresence>

          {/* Bottom Navigation Arrows */}
          <div className="mt-10 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={prev}
              aria-label="Experiencia anterior"
              className="w-10 h-10 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Siguiente experiencia"
              className="w-10 h-10 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
