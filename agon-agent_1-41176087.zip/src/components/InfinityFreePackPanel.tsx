import { Download, Server, ShieldCheck, Database, FileCode2, CheckCircle2 } from 'lucide-react';
import type { Property, FaqItem, Testimonial, SiteSettings } from '../types/eyn';

interface InfinityFreePackPanelProps {
  properties: Property[];
  faqs: FaqItem[];
  testimonials: Testimonial[];
  settings: SiteSettings;
}

const PHP_FILES = [
  {
    name: 'database.sql',
    path: '/infinityfree-php-mysql/database.sql',
    desc: 'Esquema completo MySQL utf8mb4 + tablas de propiedades, contactos, FAQs, configuración y usuario admin cifrado con bcrypt.',
  },
  {
    name: 'config.php',
    path: '/infinityfree-php-mysql/config.php',
    desc: 'Conexión segura PDO para InfinityFree (sqlXXX.infinityfree.com), cabeceras de seguridad, protección CSRF y funciones de saneamiento XSS.',
  },
  {
    name: 'index.php',
    path: '/infinityfree-php-mysql/index.php',
    desc: 'Portada pública completa en PHP 8 + MySQL con diseño EYN LUXE (negro/antracita, dorado sobrio y marfil), buscador SQL y formulario protegido.',
  },
  {
    name: 'propiedad.php',
    path: '/infinityfree-php-mysql/propiedad.php',
    desc: 'Ficha individual dinámica de cada propiedad con galería, especificaciones técnicas y solicitud directa de visita o dossier en MySQL.',
  },
  {
    name: 'admin.php',
    path: '/infinityfree-php-mysql/admin.php',
    desc: 'Panel de gestión privado en PHP con inicio de sesión seguro (password_verify), alta/edición/borrado de inmuebles, subida de fotos y bandeja de contactos.',
  },
  {
    name: '.htaccess',
    path: '/infinityfree-php-mysql/htaccess.txt',
    desc: 'Reglas Apache compatibles con InfinityFree (renombrar a .htaccess en htdocs/): codificación UTF-8, bloqueo de archivos sensibles y compresión.',
  },
  {
    name: 'INSTALACION_INFINITYFREE.txt',
    path: '/infinityfree-php-mysql/INSTALACION_INFINITYFREE.txt',
    desc: 'Guía paso a paso en español para configurar la base de datos en el cPanel de InfinityFree y publicar el proyecto en minutos.',
  },
];

function escSql(val: unknown): string {
  if (val === null || val === undefined) return "''";
  return "'" + String(val).replace(/\\/g, '\\\\').replace(/'/g, "''") + "'";
}

export default function InfinityFreePackPanel({
  properties,
  faqs,
  testimonials,
  settings,
}: InfinityFreePackPanelProps) {
  const exportLiveMysqlDump = () => {
    const lines: string[] = [
      '-- ============================================================================',
      '-- EYN LUXE – Exclusive Real Estate (Valencia, España)',
      '-- Exportación SQL sincronizada para MySQL / MariaDB (InfinityFree phpMyAdmin)',
      `-- Generado: ${new Date().toISOString()}`,
      '-- ============================================================================',
      'SET NAMES utf8mb4;',
      'SET FOREIGN_KEY_CHECKS = 0;',
      '',
      'CREATE TABLE IF NOT EXISTS `eyn_properties` (',
      '  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,',
      '  `reference` VARCHAR(50) NOT NULL,',
      '  `slug` VARCHAR(180) NOT NULL,',
      '  `title` VARCHAR(220) NOT NULL,',
      '  `subtitle` VARCHAR(255) DEFAULT NULL,',
      '  `operation` VARCHAR(60) NOT NULL DEFAULT \'Venta\',',
      '  `property_type` VARCHAR(80) NOT NULL DEFAULT \'Vivienda Exclusiva\',',
      '  `zone` VARCHAR(140) NOT NULL,',
      '  `city` VARCHAR(80) NOT NULL DEFAULT \'Valencia\',',
      '  `price` DECIMAL(14,2) NOT NULL DEFAULT 0,',
      '  `price_label` VARCHAR(80) DEFAULT NULL,',
      '  `area_m2` INT NOT NULL DEFAULT 0,',
      '  `plot_m2` INT NOT NULL DEFAULT 0,',
      '  `bedrooms` INT NOT NULL DEFAULT 0,',
      '  `bathrooms` INT NOT NULL DEFAULT 0,',
      '  `energy_rating` VARCHAR(20) DEFAULT \'A\',',
      '  `featured` TINYINT(1) NOT NULL DEFAULT 0,',
      '  `exclusive_badge` TINYINT(1) NOT NULL DEFAULT 1,',
      '  `status` VARCHAR(30) NOT NULL DEFAULT \'Disponible\',',
      '  `description` TEXT NOT NULL,',
      '  `highlights` JSON DEFAULT NULL,',
      '  `main_image` VARCHAR(500) NOT NULL,',
      '  `gallery` JSON DEFAULT NULL,',
      '  `sort_order` INT NOT NULL DEFAULT 10,',
      '  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,',
      '  PRIMARY KEY (`id`)',
      ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;',
      '',
      'TRUNCATE TABLE `eyn_properties`;',
    ];

    for (const p of properties) {
      lines.push(
        `INSERT INTO \`eyn_properties\` (\`reference\`, \`slug\`, \`title\`, \`subtitle\`, \`operation\`, \`property_type\`, \`zone\`, \`city\`, \`price\`, \`price_label\`, \`area_m2\`, \`plot_m2\`, \`bedrooms\`, \`bathrooms\`, \`energy_rating\`, \`featured\`, \`exclusive_badge\`, \`status\`, \`description\`, \`highlights\`, \`main_image\`, \`gallery\`, \`sort_order\`) VALUES (${escSql(
          p.reference
        )}, ${escSql(p.slug)}, ${escSql(p.title)}, ${escSql(p.subtitle)}, ${escSql(
          p.operation
        )}, ${escSql(p.property_type)}, ${escSql(p.zone)}, ${escSql(p.city)}, ${Number(
          p.price || 0
        )}, ${escSql(p.price_label)}, ${Number(p.area_m2 || 0)}, ${Number(
          p.plot_m2 || 0
        )}, ${Number(p.bedrooms || 0)}, ${Number(p.bathrooms || 0)}, ${escSql(
          p.energy_rating
        )}, ${p.featured ? 1 : 0}, ${p.exclusive_badge ? 1 : 0}, ${escSql(
          p.status
        )}, ${escSql(p.description)}, ${escSql(
          JSON.stringify(p.highlights || [])
        )}, ${escSql(p.main_image)}, ${escSql(
          JSON.stringify(p.gallery || [])
        )}, ${Number(p.sort_order || 10)});`
      );
    }

    lines.push(
      '',
      'CREATE TABLE IF NOT EXISTS `eyn_faqs` (',
      '  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,',
      '  `question` VARCHAR(300) NOT NULL,',
      '  `answer` TEXT NOT NULL,',
      '  `category` VARCHAR(80) DEFAULT \'General\',',
      '  `sort_order` INT DEFAULT 10,',
      '  `visible` TINYINT(1) DEFAULT 1,',
      '  PRIMARY KEY (`id`)',
      ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;',
      'TRUNCATE TABLE `eyn_faqs`;'
    );

    for (const f of faqs) {
      lines.push(
        `INSERT INTO \`eyn_faqs\` (\`question\`, \`answer\`, \`category\`, \`sort_order\`, \`visible\`) VALUES (${escSql(
          f.question
        )}, ${escSql(f.answer)}, ${escSql(f.category)}, ${Number(f.sort_order || 10)}, ${
          f.visible ? 1 : 0
        });`
      );
    }

    lines.push(
      '',
      'CREATE TABLE IF NOT EXISTS `eyn_testimonials` (',
      '  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,',
      '  `client_name` VARCHAR(140) NOT NULL,',
      '  `client_role` VARCHAR(160) NOT NULL,',
      '  `avatar_url` VARCHAR(500) DEFAULT NULL,',
      '  `quote` TEXT NOT NULL,',
      '  `operation_tag` VARCHAR(100) DEFAULT NULL,',
      '  `visible` TINYINT(1) DEFAULT 1,',
      '  `sort_order` INT DEFAULT 10,',
      '  PRIMARY KEY (`id`)',
      ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;',
      'TRUNCATE TABLE `eyn_testimonials`;'
    );

    for (const t of testimonials) {
      lines.push(
        `INSERT INTO \`eyn_testimonials\` (\`client_name\`, \`client_role\`, \`avatar_url\`, \`quote\`, \`operation_tag\`, \`visible\`, \`sort_order\`) VALUES (${escSql(
          t.client_name
        )}, ${escSql(t.client_role)}, ${escSql(t.avatar_url)}, ${escSql(t.quote)}, ${escSql(
          t.operation_tag
        )}, ${t.visible ? 1 : 0}, ${Number(t.sort_order || 10)});`
      );
    }

    lines.push(
      '',
      'CREATE TABLE IF NOT EXISTS `eyn_settings` (',
      '  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,',
      '  `setting_key` VARCHAR(100) NOT NULL UNIQUE,',
      '  `setting_value` TEXT NOT NULL,',
      '  PRIMARY KEY (`id`)',
      ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;',
      'TRUNCATE TABLE `eyn_settings`;'
    );

    for (const [k, v] of Object.entries(settings)) {
      if (v !== undefined) {
        lines.push(
          `INSERT INTO \`eyn_settings\` (\`setting_key\`, \`setting_value\`) VALUES (${escSql(
            k
          )}, ${escSql(v)});`
        );
      }
    }

    lines.push('', 'SET FOREIGN_KEY_CHECKS = 1;');

    const blob = new Blob([lines.join('\n')], { type: 'application/sql;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'eyn_luxe_sync_infinityfree.sql';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-3xl bg-[#131318] border border-[#C5A059]/30 p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/15 border border-[#C5A059]/40 text-xs text-[#DFC286]">
              <Server className="w-3.5 h-3.5" /> Compatible 100 % con Hosting Compartido InfinityFree
            </div>
            <h2 className="font-serif-luxe text-3xl text-white">
              Paquete de Producción PHP 8 + MySQL (InfinityFree)
            </h2>
            <p className="text-sm text-[#F5F1E8]/70 leading-relaxed">
              Además de esta plataforma en vivo conectada a base de datos, dispone aquí de todos los archivos nativos en <strong>PHP 8 (PDO, sentencias preparadas, protección CSRF, contraseñas cifradas con bcrypt)</strong> y <strong>MySQL</strong> optimizados para subir directamente a la carpeta <code>htdocs/</code> de InfinityFree.
            </p>
          </div>

          <button
            type="button"
            onClick={exportLiveMysqlDump}
            className="px-6 py-3.5 rounded-full bg-gradient-to-r from-[#C5A059] via-[#DFC286] to-[#A67F35] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.15em] flex items-center gap-2 shrink-0 cursor-pointer hover:brightness-110 transition-all"
          >
            <Database className="w-4 h-4" /> Exportar SQL Actualizado
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-7 pt-6 border-t border-white/10 text-xs text-[#F5F1E8]/75">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
            <span>Consultas PDO parametrizadas contra inyección SQL, validación XSS y tokens CSRF en formularios.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
            <span>Sin dependencias de consola ni Node/Composer: funciona directamente al subir por FTP o File Manager en InfinityFree.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <Database className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
            <span>Codificación utf8mb4_spanish_ci para mostrar tildes, eñes y símbolos de euro sin errores en servidores MySQL compartidos.</span>
          </div>
        </div>
      </div>

      {/* File Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PHP_FILES.map((file) => (
          <div
            key={file.name}
            className="rounded-2xl bg-[#131318] border border-white/10 p-5 flex items-start justify-between gap-4 hover:border-[#C5A059]/45 transition-colors"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <FileCode2 className="w-4 h-4 text-[#C5A059]" />
                <span className="font-mono text-sm font-semibold text-white">{file.name}</span>
              </div>
              <p className="text-xs text-[#F5F1E8]/65 leading-relaxed">{file.desc}</p>
            </div>
            <a
              href={file.path}
              download={file.name}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-[#C5A059] text-[#DFC286] hover:text-[#0A0A0C] text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> Descargar
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
