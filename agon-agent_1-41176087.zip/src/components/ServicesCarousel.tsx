import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ChevronLeft, ChevronRight } from 'lucide-react';

interface ServicesCarouselProps {
  onSelectService: (serviceName: string) => void;
}

const SERVICES = [
  {
    id: 'comercializacion',
    title: 'Comercialización Exclusiva',
    tagline: 'Tu propiedad merece destacar, no solo anunciarse.',
    items: [
      'Estrategia editorial y reportaje arquitectónico',
      'Cartera reducida con dedicación prioritaria',
      'Difusión nacional e internacional selecta',
      'Cualificación rigurosa previa a cada visita',
    ],
  },
  {
    id: 'compra',
    title: 'Compra de Propiedades',
    tagline: 'Búsqueda a medida y acceso a oportunidades privadas.',
    items: [
      'Servicio Personal Shopper Inmobiliario',
      'Identificación de viviendas singulares y off-market',
      'Auditoría técnica, urbanística y registral',
      'Negociación experta en defensa del comprador',
    ],
  },
  {
    id: 'venta',
    title: 'Venta Patrimonial',
    tagline: 'Defensa del valor real y cierre con plena seguridad.',
    items: [
      'Valoración de mercado rigurosa en Valencia',
      'Preparación estética y puesta en escena (Home Staging)',
      'Gestión integral documental y fiscal',
      'Acompañamiento personalizado hasta notaría',
    ],
  },
  {
    id: 'alquiler',
    title: 'Alquiler Exclusivo',
    tagline: 'Rentabilidad tranquila con perfiles altamente solventes.',
    items: [
      'Selección exhaustiva de arrendatarios ejecutivos',
      'Redacción contractual conforme a normativa vigente',
      'Gestión de garantías y coberturas de tranquilidad',
      'Atención cercana para propietarios e inquilinos',
    ],
  },
  {
    id: 'construccion',
    title: 'Construcción y Reforma',
    tagline: 'Arquitectura contemporánea y rehabilitación de alto nivel.',
    items: [
      'Proyectos residenciales de obra nueva llave en mano',
      'Reforma integral de viviendas históricas y áticos',
      'Interiorismo atemporal en materiales nobles',
      'Control estricto de calidades, presupuesto y plazos',
    ],
  },
  {
    id: 'asesoramiento',
    title: 'Asesoramiento Personalizado',
    tagline: 'Dirección directa por Estefanía Yáñez en Valencia.',
    items: [
      'Consultoría patrimonial e inversión inmobiliaria',
      'Análisis de rentabilidad por zonas prime',
      'Acompañamiento a clientes nacionales e internacionales',
      'Confidencialidad absoluta en cada operación',
    ],
  },
];

export default function ServicesCarousel({ onSelectService }: ServicesCarouselProps) {
  // Default active index 0 reproduces the glowing warm accent card from Reference Video Frame 14-15
  const [activeId, setActiveId] = useState<string>('comercializacion');
  const trackRef = useRef<HTMLDivElement>(null);

  const scrollTrack = (dir: 'left' | 'right') => {
    if (!trackRef.current) return;
    const amount = 360;
    trackRef.current.scrollBy({
      left: dir === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  return (
    <section
      id="servicios"
      className="py-24 md:py-32 bg-[#0A0A0C] border-t border-white/[0.06] overflow-hidden"
      aria-labelledby="servicios-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Reveal Heading matching Reference Video Frames 12-13 */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14 md:mb-18">
          <div className="max-w-3xl">
            <p className="text-xs uppercase tracking-[0.24em] text-[#C5A059] mb-3">
              Servicios Inmobiliarios Integrales
            </p>
            <motion.h2
              id="servicios-heading"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.65 }}
              className="font-serif-luxe text-4xl sm:text-6xl md:text-[4.25rem] leading-[1.05] text-white font-normal"
            >
              Excelencia que Habla <br className="hidden sm:block" />
              <span className="italic text-[#DFC286]">por su Propiedad</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.65, delay: 0.12 }}
              className="mt-5 text-sm sm:text-base text-[#F5F1E8]/72 leading-relaxed max-w-2xl"
            >
              En EYN LUXE abordamos cada operación en Valencia desde la excelencia técnica, estética y humana. Tanto si desea adquirir una vivienda singular, vender con máxima proyección o desarrollar un proyecto de construcción a medida, ofrecemos claridad, rigor y trato directo.
            </motion.p>
          </div>

          <div className="flex items-center gap-3 self-start lg:self-end">
            <button
              type="button"
              onClick={() => scrollTrack('left')}
              aria-label="Desplazar servicios a la izquierda"
              className="w-11 h-11 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => scrollTrack('right')}
              aria-label="Desplazar servicios a la derecha"
              className="w-11 h-11 rounded-full border border-white/15 hover:border-[#C5A059] flex items-center justify-center text-[#F5F1E8] hover:text-[#DFC286] transition-colors cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Horizontal Interactive Cards matching Reference Video Frames 14-15 */}
        <div
          ref={trackRef}
          className="flex gap-5 overflow-x-auto pb-4 no-scrollbar snap-x snap-mandatory"
        >
          {SERVICES.map((srv) => {
            const isHighlighted = activeId === srv.id;
            return (
              <div
                key={srv.id}
                onMouseEnter={() => setActiveId(srv.id)}
                onClick={() => setActiveId(srv.id)}
                className={`snap-start shrink-0 w-[300px] sm:w-[340px] min-h-[410px] rounded-[26px] p-7 sm:p-8 flex flex-col justify-between transition-all duration-500 border cursor-pointer ${
                  isHighlighted
                    ? 'bg-gradient-to-br from-[#CEAA63] via-[#B58E43] to-[#876627] border-[#DFC286] text-[#0A0A0C] shadow-[0_24px_60px_rgba(197,160,89,0.28)] -translate-y-1'
                    : 'bg-[#141419] border-white/10 text-[#F5F1E8] hover:border-[#C5A059]/45'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-4 mb-6">
                    <h3
                      className={`font-serif-luxe text-2xl sm:text-3xl leading-tight font-medium ${
                        isHighlighted ? 'text-[#0A0A0C]' : 'text-white'
                      }`}
                    >
                      {srv.title}
                    </h3>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(srv.title);
                      }}
                      aria-label={`Consultar sobre ${srv.title}`}
                      className={`w-11 h-11 rounded-full shrink-0 flex items-center justify-center transition-transform duration-300 hover:scale-105 cursor-pointer ${
                        isHighlighted
                          ? 'bg-[#F5F1E8] text-[#0A0A0C] shadow-md'
                          : 'bg-white/[0.07] text-[#F5F1E8] border border-white/10'
                      }`}
                    >
                      <ArrowUpRight className="w-5 h-5" />
                    </button>
                  </div>

                  <p
                    className={`text-xs sm:text-sm mb-6 leading-relaxed ${
                      isHighlighted ? 'text-[#0A0A0C]/85 font-medium' : 'text-[#C5A059]'
                    }`}
                  >
                    {srv.tagline}
                  </p>
                </div>

                <ul
                  className={`space-y-3 pt-5 border-t text-sm ${
                    isHighlighted
                      ? 'border-[#0A0A0C]/20 text-[#0A0A0C]/90 font-medium'
                      : 'border-white/10 text-[#F5F1E8]/75'
                  }`}
                >
                  {srv.items.map((bullet, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <span
                        className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                          isHighlighted ? 'bg-[#0A0A0C]' : 'bg-[#C5A059]'
                        }`}
                      />
                      <span>{bullet}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
