import { AnimatePresence, motion } from 'framer-motion';
import { X, Trash2, ArrowUpRight, Heart } from 'lucide-react';
import type { Property } from '../types/eyn';

interface FavoritesDrawerProps {
  open: boolean;
  onClose: () => void;
  favorites: number[];
  properties: Property[];
  onToggleFavorite: (id: number) => void;
  onSelectProperty: (property: Property) => void;
}

export default function FavoritesDrawer({
  open,
  onClose,
  favorites,
  properties,
  onToggleFavorite,
  onSelectProperty,
}: FavoritesDrawerProps) {
  const savedItems = properties.filter((p) => favorites.includes(p.id));

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end"
        >
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 260 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md h-full bg-[#111116] border-l border-[#C5A059]/30 p-6 flex flex-col justify-between"
            aria-label="Selección de propiedades favoritas"
          >
            <div className="overflow-y-auto pr-1">
              <div className="flex items-center justify-between pb-5 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-[#C5A059] fill-current" />
                  <h3 className="font-serif-luxe text-2xl text-white">Selección Privada</h3>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-[#F5F1E8] hover:border-[#C5A059] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {savedItems.length === 0 ? (
                <div className="py-16 text-center space-y-3">
                  <p className="font-serif-luxe text-2xl text-[#F5F1E8]/80">
                    Aún no ha guardado propiedades
                  </p>
                  <p className="text-xs text-[#F5F1E8]/55 leading-relaxed">
                    Pulse el icono del corazón en cualquier propiedad del catálogo para conservar su selección personalizada.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-white/10 mt-4">
                  {savedItems.map((prop) => (
                    <div key={prop.id} className="py-4 flex gap-3.5 items-center">
                      <img
                        src={prop.main_image}
                        alt={prop.title}
                        className="w-20 h-20 rounded-xl object-cover shrink-0 border border-white/10"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] uppercase tracking-[0.15em] text-[#C5A059]">
                          {prop.zone}
                        </p>
                        <h4 className="font-serif-luxe text-lg text-white truncate">
                          {prop.title}
                        </h4>
                        <p className="text-xs text-[#DFC286] font-semibold mt-0.5">
                          {prop.price_label ||
                            new Intl.NumberFormat('es-ES', {
                              style: 'currency',
                              currency: 'EUR',
                              maximumFractionDigits: 0,
                            }).format(prop.price)}
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onSelectProperty(prop);
                          }}
                          className="mt-1.5 inline-flex items-center gap-1 text-[11px] uppercase tracking-[0.14em] text-[#F5F1E8]/80 hover:text-[#DFC286] cursor-pointer"
                        >
                          Abrir ficha <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onToggleFavorite(prop.id)}
                        aria-label="Eliminar de favoritos"
                        className="p-2 text-[#F5F1E8]/50 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-white/10 text-center">
              <p className="text-[11px] text-[#F5F1E8]/55">
                EYN LUXE · Atención directa en Valencia (+34 658 659 387)
              </p>
            </div>
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
