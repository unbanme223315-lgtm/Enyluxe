import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Building2,
  Inbox,
  HelpCircle,
  Settings,
  Server,
  Plus,
  Trash2,
  Edit3,
  LogOut,
  ExternalLink,
  Upload,
  Phone,
  MessageCircle,
  Check,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import InfinityFreePackPanel from '../components/InfinityFreePackPanel';
import type { Property, Inquiry, FaqItem, Testimonial, SiteSettings } from '../types/eyn';

const EMPTY_PROP: Partial<Property> = {
  reference: 'EYN-VLC-007',
  title: '',
  subtitle: '',
  operation: 'Venta',
  property_type: 'Ático Exclusivo',
  zone: 'El Pla del Real · Valencia',
  city: 'Valencia',
  price: 950000,
  price_label: '950.000 €',
  area_m2: 180,
  plot_m2: 0,
  bedrooms: 3,
  bathrooms: 3,
  energy_rating: 'A',
  featured: true,
  exclusive_badge: true,
  status: 'Disponible',
  description: '',
  highlights: [],
  main_image: '/images/penthouse-turia.jpg',
  gallery: [],
  sort_order: 10,
};

export default function AdminPage() {
  const { user, session, signOut } = useAuth();
  const token = session?.access_token || '';

  const [tab, setTab] = useState<'propiedades' | 'contactos' | 'contenido' | 'ajustes' | 'php'>('propiedades');
  const [properties, setProperties] = useState<Property[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [faqs, setFaqs] = useState<FaqItem[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [settings, setSettings] = useState<SiteSettings>({});
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState('');

  // Property Editor State
  const [editingProp, setEditingProp] = useState<Partial<Property> | null>(null);
  const [highlightsText, setHighlightsText] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  // New FAQ / Testimonial State
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');
  const [newTestName, setNewTestName] = useState('');
  const [newTestRole, setNewTestRole] = useState('');
  const [newTestQuote, setNewTestQuote] = useState('');

  const showNotice = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3500);
  };

  const authHeaders = useCallback(
    () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    }),
    [token]
  );

  const loadAll = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const [pRes, iRes, cRes] = await Promise.all([
        fetch('/api/properties?include_all=true', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/inquiries', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/content?include_hidden=true', { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      const [pData, iData, cData] = await Promise.all([pRes.json(), iRes.json(), cRes.json()]);
      if (Array.isArray(pData)) setProperties(pData);
      if (Array.isArray(iData)) setInquiries(iData);
      if (cData) {
        setFaqs(cData.faqs || []);
        setTestimonials(cData.testimonials || []);
        setSettings(cData.settings || {});
      }
    } catch (err) {
      console.error('Admin load error:', err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleUploadImage = async (file: File) => {
    setUploadingImg(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const resultStr = String(reader.result || '');
        const base64 = resultStr.includes(',') ? resultStr.split(',')[1] : resultStr;
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: authHeaders(),
          body: JSON.stringify({
            fileName: file.name,
            fileBase64: base64,
            contentType: file.type,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error al subir fotografía');
        setEditingProp((prev) =>
          prev
            ? {
                ...prev,
                main_image: data.url,
                gallery: Array.from(new Set([data.url, ...(prev.gallery || [])])),
              }
            : prev
        );
        showNotice('Fotografía subida correctamente.');
        setUploadingImg(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      setUploadingImg(false);
    }
  };

  const handleSaveProperty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProp) return;
    const payload = {
      ...editingProp,
      highlights: highlightsText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean),
    };
    const isEdit = Boolean(editingProp.id);
    const res = await fetch('/api/properties', {
      method: isEdit ? 'PUT' : 'POST',
      headers: authHeaders(),
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      setEditingProp(null);
      showNotice(isEdit ? 'Propiedad actualizada.' : 'Nueva propiedad publicada.');
      loadAll();
    }
  };

  const handleDeleteProperty = async (id: number) => {
    const res = await fetch('/api/properties', {
      method: 'DELETE',
      headers: authHeaders(),
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      showNotice('Propiedad eliminada.');
      loadAll();
    }
  };

  const handleUpdateInquiry = async (inq: Inquiry, status: string, admin_notes: string) => {
    const res = await fetch('/api/inquiries', {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify({ id: inq.id, status, admin_notes }),
    });
    if (res.ok) {
      showNotice('Estado de consulta actualizado.');
      loadAll();
    }
  };

  const handleDeleteInquiry = async (id: number) => {
    const res = await fetch('/api/inquiries', {
      method: 'DELETE',
      headers: authHeaders(),
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      showNotice('Consulta eliminada.');
      loadAll();
    }
  };

  const handleAddFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFaqQ.trim() || !newFaqA.trim()) return;
    const res = await fetch('/api/content', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ entity: 'faq', question: newFaqQ, answer: newFaqA }),
    });
    if (res.ok) {
      setNewFaqQ('');
      setNewFaqA('');
      showNotice('Pregunta frecuente añadida.');
      loadAll();
    }
  };

  const handleAddTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTestName.trim() || !newTestQuote.trim()) return;
    const res = await fetch('/api/content', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        entity: 'testimonial',
        client_name: newTestName,
        client_role: newTestRole || 'Cliente EYN LUXE · Valencia',
        quote: newTestQuote,
        avatar_url: '',
      }),
    });
    if (res.ok) {
      setNewTestName('');
      setNewTestRole('');
      setNewTestQuote('');
      showNotice('Valoración publicada.');
      loadAll();
    }
  };

  const handleDeleteContent = async (entity: 'faq' | 'testimonial', id: number) => {
    const res = await fetch('/api/content', {
      method: 'DELETE',
      headers: authHeaders(),
      body: JSON.stringify({ entity, id }),
    });
    if (res.ok) {
      showNotice('Elemento eliminado.');
      loadAll();
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/content', {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify({ entity: 'settings', settings }),
    });
    if (res.ok) showNotice('Datos de marca y textos legales guardados.');
  };

  const newLeadsCount = inquiries.filter((i) => i.status === 'Nueva').length;

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-[#F5F1E8]">
      {/* Top Admin Header */}
      <header className="sticky top-0 z-30 bg-[#111116]/95 backdrop-blur-xl border-b border-[#C5A059]/25 px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-serif-luxe text-2xl text-white">
              EYN <span className="text-[#C5A059]">LUXE</span> · Panel de Dirección
            </h1>
            <p className="text-xs text-[#F5F1E8]/55">Sesión activa: {user?.email}</p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="px-4 py-2 rounded-full border border-white/15 hover:border-[#C5A059] text-xs uppercase tracking-[0.14em] flex items-center gap-1.5"
            >
              Ver Web Pública <ExternalLink className="w-3.5 h-3.5" />
            </Link>
            <button
              type="button"
              onClick={signOut}
              className="px-4 py-2 rounded-full bg-red-950/50 border border-red-500/35 text-xs text-red-200 hover:bg-red-900/50 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" /> Salir
            </button>
          </div>
        </div>
      </header>

      {toast && (
        <div className="fixed bottom-6 right-6 z-50 px-5 py-3 rounded-2xl bg-[#C5A059] text-[#0A0A0C] text-xs font-bold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 border-b border-white/10 pb-4">
          {[
            { id: 'propiedades', label: `Propiedades (${properties.length})`, icon: Building2 },
            {
              id: 'contactos',
              label: `Solicitudes (${inquiries.length})${newLeadsCount ? ` · ${newLeadsCount} nuevas` : ''}`,
              icon: Inbox,
            },
            { id: 'contenido', label: 'FAQ & Experiencias', icon: HelpCircle },
            { id: 'ajustes', label: 'Marca & Aviso Legal', icon: Settings },
            { id: 'php', label: 'Paquete PHP + MySQL (InfinityFree)', icon: Server },
          ].map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id as typeof tab)}
                className={`px-4 py-2.5 rounded-full text-xs font-semibold uppercase tracking-[0.12em] flex items-center gap-2 transition-all cursor-pointer ${
                  active
                    ? 'bg-[#C5A059] text-[#0A0A0C]'
                    : 'bg-[#14141A] text-[#F5F1E8]/75 hover:text-white border border-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" /> {item.label}
              </button>
            );
          })}
        </div>

        {loading ? (
          <p className="text-sm text-[#F5F1E8]/60 py-12">Cargando datos en tiempo real...</p>
        ) : (
          <>
            {/* TAB 1: PROPIEDADES */}
            {tab === 'propiedades' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="font-serif-luxe text-3xl text-white">Gestión de Cartera Inmobiliaria</h2>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingProp({
                        ...EMPTY_PROP,
                        reference: `EYN-VLC-00${properties.length + 1}`,
                      });
                      setHighlightsText(
                        'Terraza privada con vistas despejadas\nCalidades de alta gama y domótica integral'
                      );
                    }}
                    className="px-5 py-2.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.14em] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Nueva Propiedad
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {properties.map((p) => (
                    <div
                      key={p.id}
                      className="rounded-2xl bg-[#131318] border border-white/10 p-4 flex gap-4 items-center"
                    >
                      <img
                        src={p.main_image}
                        alt={p.title}
                        className="w-24 h-24 rounded-xl object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider">
                          <span className="text-[#C5A059] font-bold">{p.reference}</span>
                          <span className="px-2 py-0.5 rounded bg-white/10 text-white">{p.operation}</span>
                          <span className="px-2 py-0.5 rounded bg-[#C5A059]/20 text-[#DFC286]">
                            {p.status}
                          </span>
                        </div>
                        <h3 className="font-serif-luxe text-xl text-white truncate mt-1">{p.title}</h3>
                        <p className="text-xs text-[#F5F1E8]/60 truncate">
                          {p.zone} · {p.price_label || `${p.price} €`}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingProp(p);
                            setHighlightsText((p.highlights || []).join('\n'));
                          }}
                          className="p-2 rounded-lg bg-white/[0.06] hover:bg-[#C5A059] hover:text-[#0A0A0C] cursor-pointer"
                          title="Editar"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteProperty(p.id)}
                          className="p-2 rounded-lg bg-red-950/50 text-red-300 hover:bg-red-600 hover:text-white cursor-pointer"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: CONTACTOS / LEADS */}
            {tab === 'contactos' && (
              <div className="space-y-4">
                <h2 className="font-serif-luxe text-3xl text-white mb-4">
                  Bandeja de Consultas y Captación de Propietarios
                </h2>
                {inquiries.length === 0 ? (
                  <p className="text-sm text-[#F5F1E8]/60 py-10">No hay consultas registradas todavía.</p>
                ) : (
                  inquiries.map((inq) => (
                    <div
                      key={inq.id}
                      className="rounded-2xl bg-[#131318] border border-white/10 p-6 space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <span className="px-3 py-1 rounded-full bg-[#C5A059]/20 text-[#DFC286] text-xs font-semibold mr-2">
                            {inq.service_type}
                          </span>
                          {inq.property_ref && (
                            <span className="text-xs text-[#C5A059]">Ref: {inq.property_ref}</span>
                          )}
                          <h3 className="font-serif-luxe text-2xl text-white mt-1">{inq.full_name}</h3>
                        </div>

                        <div className="flex items-center gap-2">
                          <select
                            value={inq.status}
                            onChange={(e) =>
                              handleUpdateInquiry(inq, e.target.value, inq.admin_notes || '')
                            }
                            className="px-3 py-1.5 rounded-lg bg-[#0A0A0C] border border-[#C5A059]/40 text-xs text-[#DFC286]"
                          >
                            <option value="Nueva">Nueva</option>
                            <option value="En gestión">En gestión</option>
                            <option value="Atendida">Atendida</option>
                          </select>
                          <button
                            type="button"
                            onClick={() => handleDeleteInquiry(inq.id)}
                            className="p-2 rounded-lg text-red-300 hover:bg-red-950/60 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <p className="text-sm text-[#F5F1E8]/85 bg-[#0A0A0C] p-4 rounded-xl border border-white/8">
                        {inq.message}
                      </p>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-[#F5F1E8]/70 pt-1">
                        <a href={`tel:${inq.phone}`} className="flex items-center gap-1 text-[#DFC286]">
                          <Phone className="w-3.5 h-3.5" /> {inq.phone}
                        </a>
                        <a
                          href={`https://wa.me/${inq.phone.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-emerald-300"
                        >
                          <MessageCircle className="w-3.5 h-3.5" /> Abrir WhatsApp
                        </a>
                        <span>Email: {inq.email}</span>
                        {inq.budget_or_valuation && (
                          <span>Zona / Presupuesto: {inq.budget_or_valuation}</span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 3: FAQ & EXPERIENCIAS */}
            {tab === 'contenido' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-serif-luxe text-2xl text-white">Preguntas Frecuentes (FAQ)</h3>
                  <form onSubmit={handleAddFaq} className="rounded-2xl bg-[#131318] border border-white/10 p-5 space-y-3">
                    <input
                      type="text"
                      required
                      placeholder="Nueva pregunta frecuente..."
                      value={newFaqQ}
                      onChange={(e) => setNewFaqQ(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                    <textarea
                      rows={3}
                      required
                      placeholder="Respuesta clara y profesional..."
                      value={newFaqA}
                      onChange={(e) => setNewFaqA(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold uppercase cursor-pointer"
                    >
                      Añadir Pregunta
                    </button>
                  </form>

                  <div className="space-y-2.5">
                    {faqs.map((f) => (
                      <div
                        key={f.id}
                        className="rounded-xl bg-[#131318] border border-white/8 p-4 flex justify-between gap-3"
                      >
                        <div>
                          <p className="font-medium text-sm text-white">{f.question}</p>
                          <p className="text-xs text-[#F5F1E8]/60 mt-1 line-clamp-2">{f.answer}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteContent('faq', f.id)}
                          className="text-red-300 hover:text-red-400 shrink-0 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-serif-luxe text-2xl text-white">Experiencias de Clientes</h3>
                  <form
                    onSubmit={handleAddTestimonial}
                    className="rounded-2xl bg-[#131318] border border-white/10 p-5 space-y-3"
                  >
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        placeholder="Nombre o iniciales (ej. M. G.)"
                        value={newTestName}
                        onChange={(e) => setNewTestName(e.target.value)}
                        className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                      />
                      <input
                        type="text"
                        placeholder="Operación / Zona en Valencia"
                        value={newTestRole}
                        onChange={(e) => setNewTestRole(e.target.value)}
                        className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                      />
                    </div>
                    <textarea
                      rows={3}
                      required
                      placeholder="Testimonio real..."
                      value={newTestQuote}
                      onChange={(e) => setNewTestQuote(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold uppercase cursor-pointer"
                    >
                      Publicar Experiencia
                    </button>
                  </form>

                  <div className="space-y-2.5">
                    {testimonials.map((t) => (
                      <div
                        key={t.id}
                        className="rounded-xl bg-[#131318] border border-white/8 p-4 flex justify-between gap-3"
                      >
                        <div>
                          <p className="font-medium text-sm text-[#DFC286]">
                            {t.client_name} · <span className="text-white/60">{t.client_role}</span>
                          </p>
                          <p className="text-xs text-[#F5F1E8]/75 mt-1 italic">“{t.quote}”</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteContent('testimonial', t.id)}
                          className="text-red-300 hover:text-red-400 shrink-0 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: AJUSTES DE MARCA & LEGAL */}
            {tab === 'ajustes' && (
              <form
                onSubmit={handleSaveSettings}
                className="max-w-3xl rounded-3xl bg-[#131318] border border-white/10 p-6 sm:p-8 space-y-4"
              >
                <h2 className="font-serif-luxe text-3xl text-white">
                  Configuración Corporativa y Aviso Legal
                </h2>
                <p className="text-xs text-[#F5F1E8]/60">
                  Complete aquí su correo corporativo o datos registrales/fiscales (NIF/CIF y domicilio profesional) cuando desee mostrarlos en el Aviso Legal público, sin datos ficticios.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-[#C5A059] mb-1">Responsable Comercial</label>
                    <input
                      type="text"
                      value={settings.director_name || ''}
                      onChange={(e) => setSettings({ ...settings, director_name: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#C5A059] mb-1">Teléfono Visible</label>
                    <input
                      type="text"
                      value={settings.phone_display || ''}
                      onChange={(e) => setSettings({ ...settings, phone_display: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#C5A059] mb-1">
                      Correo Corporativo Oficial (opcional)
                    </label>
                    <input
                      type="email"
                      placeholder="Pendiente de definir por EYN LUXE"
                      value={settings.corporate_email || ''}
                      onChange={(e) => setSettings({ ...settings, corporate_email: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#C5A059] mb-1">Ubicación / Domicilio</label>
                    <input
                      type="text"
                      value={settings.postal_address || ''}
                      onChange={(e) => setSettings({ ...settings, postal_address: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-[#C5A059] mb-1">
                    Datos Fiscales / NIF para Aviso Legal (LSSI-CE)
                  </label>
                  <input
                    type="text"
                    value={settings.legal_id_note || ''}
                    onChange={(e) => setSettings({ ...settings, legal_id_note: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="px-7 py-3 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.16em] cursor-pointer"
                >
                  Guardar Configuración
                </button>
              </form>
            )}

            {/* TAB 5: INFINITYFREE PHP + MYSQL */}
            {tab === 'php' && (
              <InfinityFreePackPanel
                properties={properties}
                faqs={faqs}
                testimonials={testimonials}
                settings={settings}
              />
            )}
          </>
        )}
      </div>

      {/* Property Create / Edit Modal */}
      {editingProp && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleSaveProperty}
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#14141A] border border-[#C5A059]/40 p-6 sm:p-8 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-serif-luxe text-2xl text-white">
                {editingProp.id ? 'Editar Propiedad' : 'Nueva Propiedad Exclusiva'}
              </h3>
              <button
                type="button"
                onClick={() => setEditingProp(null)}
                className="w-8 h-8 rounded-full border border-white/15 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                required
                placeholder="Referencia (EYN-VLC-001)"
                value={editingProp.reference || ''}
                onChange={(e) => setEditingProp({ ...editingProp, reference: e.target.value })}
                className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <select
                value={editingProp.operation || 'Venta'}
                onChange={(e) => setEditingProp({ ...editingProp, operation: e.target.value })}
                className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              >
                <option value="Venta">Venta</option>
                <option value="Alquiler">Alquiler</option>
                <option value="Construcción">Construcción</option>
                <option value="Comercialización Exclusiva">Comercialización Exclusiva</option>
              </select>
              <select
                value={editingProp.status || 'Disponible'}
                onChange={(e) => setEditingProp({ ...editingProp, status: e.target.value })}
                className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              >
                <option value="Disponible">Disponible</option>
                <option value="Reservado">Reservado</option>
                <option value="Vendido">Vendido</option>
              </select>
            </div>

            <input
              type="text"
              required
              placeholder="Título editorial de la propiedad *"
              value={editingProp.title || ''}
              onChange={(e) => setEditingProp({ ...editingProp, title: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                required
                placeholder="Zona (ej. El Pla del Real · Valencia)"
                value={editingProp.zone || ''}
                onChange={(e) => setEditingProp({ ...editingProp, zone: e.target.value })}
                className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <input
                type="text"
                placeholder="Tipología (ej. Ático Dúplex)"
                value={editingProp.property_type || ''}
                onChange={(e) => setEditingProp({ ...editingProp, property_type: e.target.value })}
                className="px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <input
                type="number"
                placeholder="Precio numérico"
                value={editingProp.price ?? 0}
                onChange={(e) => setEditingProp({ ...editingProp, price: Number(e.target.value) })}
                className="px-3 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <input
                type="text"
                placeholder="Etiqueta (1.850.000 €)"
                value={editingProp.price_label || ''}
                onChange={(e) => setEditingProp({ ...editingProp, price_label: e.target.value })}
                className="px-3 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <input
                type="number"
                placeholder="m²"
                value={editingProp.area_m2 ?? 0}
                onChange={(e) => setEditingProp({ ...editingProp, area_m2: Number(e.target.value) })}
                className="px-3 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <input
                type="number"
                placeholder="Dorm."
                value={editingProp.bedrooms ?? 0}
                onChange={(e) => setEditingProp({ ...editingProp, bedrooms: Number(e.target.value) })}
                className="px-3 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <input
                type="number"
                placeholder="Baños"
                value={editingProp.bathrooms ?? 0}
                onChange={(e) => setEditingProp({ ...editingProp, bathrooms: Number(e.target.value) })}
                className="px-3 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 items-center">
              <input
                type="text"
                placeholder="URL imagen principal"
                value={editingProp.main_image || ''}
                onChange={(e) => setEditingProp({ ...editingProp, main_image: e.target.value })}
                className="flex-1 w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
              />
              <label className="px-4 py-2.5 rounded-xl bg-white/[0.08] hover:bg-[#C5A059] hover:text-[#0A0A0C] text-xs font-semibold flex items-center gap-2 cursor-pointer shrink-0">
                <Upload className="w-4 h-4" />
                {uploadingImg ? 'Subiendo...' : 'Subir Foto'}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleUploadImage(f);
                  }}
                />
              </label>
            </div>

            <textarea
              rows={3}
              required
              placeholder="Descripción detallada de la propiedad..."
              value={editingProp.description || ''}
              onChange={(e) => setEditingProp({ ...editingProp, description: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
            />

            <textarea
              rows={3}
              placeholder="Puntos destacados (uno por línea)..."
              value={highlightsText}
              onChange={(e) => setHighlightsText(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white"
            />

            <label className="flex items-center gap-2 text-xs text-[#DFC286] cursor-pointer">
              <input
                type="checkbox"
                checked={Boolean(editingProp.featured)}
                onChange={(e) => setEditingProp({ ...editingProp, featured: e.target.checked })}
                className="accent-[#C5A059]"
              />
              Destacar en la «Colección Exclusiva» de portada
            </label>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingProp(null)}
                className="px-5 py-2.5 rounded-full border border-white/15 text-xs uppercase cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-7 py-2.5 rounded-full bg-[#C5A059] text-[#0A0A0C] text-xs font-bold uppercase cursor-pointer"
              >
                Guardar Propiedad
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
