import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, ArrowLeft, Sparkles, LogIn } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';

export default function LoginPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [infoMsg, setInfoMsg] = useState('');

  useEffect(() => {
    if (user) {
      navigate('/admin', { replace: true });
    }
  }, [user, navigate]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfoMsg('');
    setLoading(true);
    try {
      if (isSignUp) {
        const { error: signUpErr } = await supabase.auth.signUp({ email, password });
        if (signUpErr) throw signUpErr;
        setInfoMsg('Cuenta creada correctamente. Accediendo al panel...');
      } else {
        const { error: signInErr } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (signInErr) throw signInErr;
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Credenciales no válidas.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoAccess = async () => {
    setError('');
    setLoading(true);
    try {
      const { error: signInErr } = await supabase.auth.signInWithPassword({
        email: 'admin@eynluxe.es',
        password: 'EynLuxe2026!',
      });
      if (signInErr) throw signInErr;
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error al iniciar acceso de demostración.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-[#F5F1E8] flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 20%, rgba(197,160,89,0.16) 0%, rgba(10,10,12,0) 60%)',
        }}
      />

      <div className="relative z-10 w-full max-w-md">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#F5F1E8]/65 hover:text-[#DFC286] mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Volver a la web pública
        </Link>

        <div className="rounded-[28px] bg-[#131318] border border-[#C5A059]/30 p-8 sm:p-10 shadow-2xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-11 h-11 rounded-full border border-[#C5A059]/60 bg-[#0A0A0C] flex items-center justify-center text-[#DFC286]">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h1 className="font-serif-luxe text-2xl text-white">Gestión EYN LUXE</h1>
              <p className="text-[11px] uppercase tracking-[0.2em] text-[#C5A059]">
                Estefanía Yáñez · Valencia
              </p>
            </div>
          </div>

          <form onSubmit={handleEmailAuth} className="space-y-4">
            <div>
              <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                Correo electrónico
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@eynluxe.es"
                className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-[0.14em] text-[#F5F1E8]/70 mb-1.5">
                Contraseña
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl bg-[#0A0A0C] border border-white/12 text-sm text-white focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            {error && (
              <p className="text-xs text-red-400 bg-red-950/40 border border-red-500/30 rounded-xl px-3.5 py-2.5">
                {error}
              </p>
            )}
            {infoMsg && (
              <p className="text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 rounded-xl px-3.5 py-2.5">
                {infoMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#C5A059] via-[#DFC286] to-[#A78036] text-[#0A0A0C] text-xs font-bold uppercase tracking-[0.16em] flex items-center justify-center gap-2 hover:brightness-110 transition-all disabled:opacity-50 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              {loading ? 'Verificando...' : isSignUp ? 'Crear Cuenta Administradora' : 'Acceder al Panel'}
            </button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-[#F5F1E8]/40">
            <span className="flex-1 h-px bg-white/10" />
            <span>o acceso rápido</span>
            <span className="flex-1 h-px bg-white/10" />
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={() => signInWithGoogle('EYN LUXE – Exclusive Real Estate')}
              className="w-full py-3 rounded-full border border-white/15 hover:border-[#C5A059] text-xs uppercase tracking-[0.14em] text-white transition-colors cursor-pointer"
            >
              Continuar con Google
            </button>

            <button
              type="button"
              onClick={handleDemoAccess}
              disabled={loading}
              className="w-full py-3 rounded-full bg-[#C5A059]/12 border border-[#C5A059]/40 hover:bg-[#C5A059]/20 text-xs text-[#DFC286] flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" /> Acceso directo de prueba (Demo Admin)
            </button>
          </div>

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => setIsSignUp((v) => !v)}
              className="text-xs text-[#F5F1E8]/55 hover:text-[#DFC286] cursor-pointer"
            >
              {isSignUp
                ? '¿Ya dispone de credenciales? Iniciar sesión'
                : '¿Registrar nuevo administrador autorizado? Crear cuenta'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
