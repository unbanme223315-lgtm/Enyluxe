import { useState, useEffect, useCallback } from 'react';
import Navbar from '../components/Navbar';
import HeroMosaic from '../components/HeroMosaic';
import ExclusiveShowcase from '../components/ExclusiveShowcase';
import PropertyCatalog from '../components/PropertyCatalog';
import PropertyDetailModal from '../components/PropertyDetailModal';
import FavoritesDrawer from '../components/FavoritesDrawer';
import WhyChooseUs from '../components/WhyChooseUs';
import ServicesCarousel from '../components/ServicesCarousel';
import PrimeZones from '../components/PrimeZones';
import BrandManifesto from '../components/BrandManifesto';
import TestimonialsSection from '../components/TestimonialsSection';
import FaqSection from '../components/FaqSection';
import ContactAndFooter from '../components/ContactAndFooter';
import type { Property, FaqItem, Testimonial, SiteSettings } from '../types/eyn';

const FAVORITES_KEY = 'eyn_luxe_favorites_v1';

export default function HomePage() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [faqs, setFaqs] = useState<FaqItem[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [settings, setSettings] = useState<SiteSettings>({});
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState('');

  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      const raw = localStorage.getItem(FAVORITES_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [favoritesOpen, setFavoritesOpen] = useState(false);
  const [zoneFilter, setZoneFilter] = useState('');
  const [preselectedService, setPreselectedService] = useState('');

  const fetchAllData = useCallback(async () => {
    setLoading(true);
    setApiError('');
    try {
      const [propsRes, contentRes] = await Promise.all([
        fetch('/api/properties'),
        fetch('/api/content'),
      ]);
      if (!propsRes.ok) throw new Error('Error al cargar el catálogo de propiedades');
      if (!contentRes.ok) throw new Error('Error al cargar el contenido corporativo');

      const propsData = await propsRes.json();
      const contentData = await contentRes.json();

      setProperties(Array.isArray(propsData) ? propsData : []);
      setFaqs(Array.isArray(contentData.faqs) ? contentData.faqs : []);
      setTestimonials(Array.isArray(contentData.testimonials) ? contentData.testimonials : []);
      setSettings(contentData.settings || {});
    } catch (err: unknown) {
      console.error('Load error:', err);
      setApiError(
        err instanceof Error
          ? err.message
          : 'No se pudo establecer conexión con el servidor.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
      } catch {
        // ignore storage quota issues
      }
      return next;
    });
  };

  const scrollToSection = (elementId: string) => {
    const el = document.getElementById(elementId);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScrollToContact = (service?: string) => {
    if (service) setPreselectedService(service);
    scrollToSection('contacto');
  };

  const handleSelectZone = (zoneKeyword: string) => {
    setZoneFilter(zoneKeyword);
    scrollToSection('catalogo');
  };

  const directorName = settings.director_name || 'Estefanía Yáñez';
  const location = settings.location || 'Valencia, España';
  const phoneDisplay = settings.phone_display || '+34 658 659 387';
  const phoneClean = settings.phone_clean || '34658659387';
  const heroSlogan =
    settings.hero_slogan || 'Propiedades exclusivas para personas excepcionales.';
  const keyMessage =
    settings.key_message || 'Tu propiedad merece destacar, no solo anunciarse.';

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-[#F5F1E8]">
      <Navbar
        favoritesCount={favorites.length}
        onOpenFavorites={() => setFavoritesOpen(true)}
        onScrollToContact={handleScrollToContact}
        phoneDisplay={phoneDisplay}
        phoneClean={phoneClean}
      />

      {apiError && (
        <div className="fixed top-20 inset-x-4 max-w-xl mx-auto z-40 rounded-2xl bg-red-950/90 border border-red-500/40 px-4 py-3 text-xs text-red-200 flex items-center justify-between gap-4">
          <span>{apiError}</span>
          <button
            type="button"
            onClick={fetchAllData}
            className="px-3 py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-white font-semibold cursor-pointer"
          >
            Reintentar
          </button>
        </div>
      )}

      <main>
        <HeroMosaic
          slogan={heroSlogan}
          directorName={directorName}
          location={location}
          onExploreCatalog={() => scrollToSection('catalogo')}
          onSellProperty={() => handleScrollToContact('Comercialización Exclusiva')}
        />

        <ExclusiveShowcase
          properties={properties}
          onSelectProperty={setSelectedProperty}
          keyMessage={keyMessage}
        />

        <PropertyCatalog
          properties={properties}
          loading={loading}
          favorites={favorites}
          onToggleFavorite={toggleFavorite}
          onSelectProperty={setSelectedProperty}
          externalZoneFilter={zoneFilter}
          onClearExternalZone={() => setZoneFilter('')}
        />

        <WhyChooseUs keyMessage={keyMessage} />

        <ServicesCarousel onSelectService={handleScrollToContact} />

        <PrimeZones onSelectZone={handleSelectZone} />

        <BrandManifesto keyMessage={keyMessage} directorName={directorName} />

        <TestimonialsSection testimonials={testimonials} />

        <FaqSection faqs={faqs} />

        <ContactAndFooter
          settings={settings}
          preselectedService={preselectedService}
        />
      </main>

      <PropertyDetailModal
        property={selectedProperty}
        onClose={() => setSelectedProperty(null)}
        phoneDisplay={phoneDisplay}
        phoneClean={phoneClean}
        directorName={directorName}
      />

      <FavoritesDrawer
        open={favoritesOpen}
        onClose={() => setFavoritesOpen(false)}
        favorites={favorites}
        properties={properties}
        onToggleFavorite={toggleFavorite}
        onSelectProperty={setSelectedProperty}
      />
    </div>
  );
}
